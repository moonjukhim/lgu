#!/usr/bin/env bash
# Day 2 v2 — 내 AWS 계정에 실습 환경을 한 번에 준비합니다 (참가자가 각자 자기 계정의 CloudShell에서 실행)
#
#   bash ~/day2/setup/setup.sh user07           사전 점검 → 네트워크(d2-shared) → 개발팀 서비스(d2-user07) → 응답 확인
#   bash ~/day2/setup/setup.sh user07 --check   사전 점검만 (교육 전날 사전 과제)
#
# 이 스크립트는 "개발팀이 서비스를 배포해 둔 상태"를 만드는 준비 작업입니다. 실습 내용이 아닙니다.
# 경보 · SLO · 대시보드 · k6 · FIS 실험 · 게이트 · Bedrock 호출은 실습 가이드를 보며 직접 입력합니다.
# 여러 번 실행해도 안전합니다. 이미 있는 스택은 그대로 두거나 바뀐 부분만 반영합니다.
set -uo pipefail
export AWS_REGION=ap-northeast-2 AWS_DEFAULT_REGION=ap-northeast-2
DIR=$(cd "$(dirname "$0")" && pwd)
ME=${1:-${ME:-}}
MODE=${2:-}
NEED_VCPU=8          # ASG 최대 4대 × t3.micro 2 vCPU
FAIL=0

ok()   { printf '  ✔ %s\n' "$*"; }
warn() { printf '  △ %s\n' "$*"; }
bad()  { printf '  ✗ %s\n' "$*"; FAIL=1; }

if [[ ! "$ME" =~ ^user[0-9]{2}$ ]]; then
  echo "사용법: bash ~/day2/setup/setup.sh user07   (user07 자리에 명단의 내 번호)"
  exit 1
fi

echo "═══ 1. 사전 점검 (리전 $AWS_REGION · 참가자 ID $ME)"

ARN=$(aws sts get-caller-identity --query Arn --output text 2>/dev/null) \
  || { echo "  ✗ AWS 자격 증명을 찾지 못했습니다. 콘솔에서 연 CloudShell인지 확인하세요."; exit 1; }
ACCT=$(aws sts get-caller-identity --query Account --output text)
ok "계정 $ACCT · $ARN"
[[ "$ARN" == *":root" ]] && warn "루트 사용자로 접속했습니다. 실습에는 문제없지만 루트 액세스 키는 만들지 마세요."

Q=$(aws service-quotas get-service-quota --service-code ec2 --quota-code L-1216C47A \
      --query "Quota.Value" --output text 2>/dev/null || echo "?")
if [[ "$Q" == "?" ]]; then
  warn "EC2 vCPU 한도를 읽지 못했습니다. 확장이 4대까지 안 되면 강사에게 알리세요."
elif awk -v q="$Q" -v n="$NEED_VCPU" 'BEGIN{exit !(q>=n)}'; then
  ok "EC2 온디맨드 Standard vCPU 한도 ${Q%.*} (필요 $NEED_VCPU 이상)"
else
  bad "EC2 vCPU 한도 ${Q%.*} < $NEED_VCPU — Service Quotas 콘솔에서 'Running On-Demand Standard' 한도 증설을 요청하세요."
fi

USED=$(aws ec2 describe-instances --filters Name=instance-state-name,Values=pending,running \
         --query "length(Reservations[].Instances[?!(Tags[?Key=='Lab' && Value=='day2'])][])" --output text 2>/dev/null || echo 0)
[[ "$USED" =~ ^[0-9]+$ ]] && (( USED > 0 )) && warn "실습과 무관한 실행 중 인스턴스 $USED 대가 vCPU 한도를 함께 씁니다."

AZN=$(aws ec2 describe-availability-zones --query "length(AvailabilityZones[?State=='available'])" --output text 2>/dev/null || echo 0)
(( AZN >= 2 )) && ok "가용 영역 $AZN 개" || bad "가용 영역을 2개 이상 찾지 못했습니다."

aws fis list-actions --max-results 1 >/dev/null 2>&1 && ok "AWS FIS 사용 가능" || bad "AWS FIS를 호출하지 못했습니다."

# SLO 기능이 쓰는 서비스 연결 역할(AWSServiceRoleForCloudWatchApplicationSignals)을 미리 만들어 둡니다.
if aws application-signals start-discovery >/dev/null 2>&1; then
  ok "CloudWatch Application Signals(SLO) 사용 준비"
else
  warn "Application Signals 준비 호출 실패 — 실습① SLO 생성 화면에서 자동으로 만들어질 수 있습니다."
fi

if [[ -n "${TARGET_MODEL:-}" && -n "${JUDGE_MODEL:-}" ]]; then
  for m in "$TARGET_MODEL" "$JUDGE_MODEL"; do
    if aws bedrock-runtime converse --model-id "$m" \
         --messages '[{"role":"user","content":[{"text":"ping"}]}]' \
         --inference-config '{"maxTokens":5}' >/dev/null 2>/tmp/d2-bedrock.err; then
      ok "Bedrock 모델 호출 가능: $m"
    else
      bad "Bedrock 모델 호출 실패: $m — $(tail -c 200 /tmp/d2-bedrock.err)"
    fi
  done
else
  warn "Bedrock 모델 확인은 건너뜀. 확인하려면 강사가 공지한 ID로: TARGET_MODEL=<ID> JUDGE_MODEL=<ID> bash $0 $ME --check"
fi

if [[ "$MODE" == "--check" ]]; then
  echo
  (( FAIL )) && echo "✗ 해결할 항목이 있습니다. 위의 ✗ 줄을 강사에게 알려 주세요." || echo "✔ 사전 점검 통과. 교육 당일 아침에 --check 없이 다시 실행합니다."
  exit $FAIL
fi
if (( FAIL )); then
  echo; echo "✗ 사전 점검에서 문제가 있어 배포하지 않았습니다. 위의 ✗ 줄을 해결한 뒤 다시 실행하세요."
  exit 1
fi

stack_status() { aws cloudformation describe-stacks --stack-name "$1" --query "Stacks[0].StackStatus" --output text 2>/dev/null || echo NONE; }

clear_failed() {   # 처음 만들다 실패한 스택은 지워야 다시 만들 수 있습니다
  local st; st=$(stack_status "$1")
  if [[ "$st" == "ROLLBACK_COMPLETE" || "$st" == "ROLLBACK_FAILED" ]]; then
    warn "$1 이 $st 상태입니다. 지우고 다시 만듭니다."
    aws cloudformation delete-stack --stack-name "$1"
    aws cloudformation wait stack-delete-complete --stack-name "$1"
  fi
}

deploy() {   # $1 스택 이름, $2 템플릿, 나머지: 추가 옵션
  local name=$1 tpl=$2; shift 2
  clear_failed "$name"
  if aws cloudformation deploy --stack-name "$name" --template-file "$DIR/$tpl" \
       --no-fail-on-empty-changeset --tags Lab=day2 Owner="$ME" "$@" >/tmp/d2-deploy.log 2>&1; then
    ok "$name $(stack_status "$name")"
  else
    bad "$name 배포 실패 ($(stack_status "$name"))"
    tail -n 5 /tmp/d2-deploy.log | sed 's/^/      /'
    echo "      실패 원인: aws cloudformation describe-stack-events --stack-name $name --max-items 10 \\"
    echo "        --query \"StackEvents[?contains(ResourceStatus,'FAILED')].[LogicalResourceId,ResourceStatusReason]\" --output table"
    exit 1
  fi
}

echo
echo "═══ 2. 네트워크 d2-shared (약 1분)"
deploy d2-shared d2-shared.yaml

echo
echo "═══ 3. 개발팀 서비스 d2-$ME (약 4~5분 — 창을 닫아도 배포는 계속됩니다)"
deploy "d2-$ME" d2-user-service.yaml --parameter-overrides UserId="$ME" --capabilities CAPABILITY_NAMED_IAM

out() { aws cloudformation describe-stacks --stack-name "d2-$ME" \
          --query "Stacks[0].Outputs[?OutputKey=='$1'].OutputValue" --output text; }
URL=$(out ServiceUrl); TGA=$(out TargetGroupArn)

echo
echo "═══ 4. 서비스 응답 확인 (정상 대상 2대 + 준비 완료까지 최대 6분)"
for i in $(seq 1 36); do
  H=$(aws elbv2 describe-target-health --target-group-arn "$TGA" \
        --query "length(TargetHealthDescriptions[?TargetHealth.State=='healthy'])" --output text 2>/dev/null || echo 0)
  W=$(curl -s -m 5 "$URL/bill" | grep -o '"warm": *true' || true)
  printf '\r  %3ds  정상 대상 %s/2  warm=%s   ' $((i*10)) "$H" "${W:+true}"
  [[ "$H" == "2" && -n "$W" ]] && break
  sleep 10
done
echo
if [[ "$H" == "2" && -n "$W" ]]; then
  ok "서비스가 응답합니다: $URL/bill"
else
  warn "아직 준비 중입니다. 2~3분 뒤 'bash ~/day2/setup/status.sh $ME' 로 다시 확인하세요."
fi

echo
echo "✔ 준비 완료. 실습① A-1에서 스택 출력값을 직접 조회해 환경 변수를 만듭니다."
echo "  진행 확인: bash ~/day2/setup/status.sh $ME     교육 종료 후 삭제: bash ~/day2/setup/cleanup.sh $ME"
