# setup — 내 계정에 실습 환경 준비 · 확인 · 정리

참가자마다 자기 AWS 계정이 있으므로, 실습 환경도 각자 자기 계정에 만듭니다. 모든 명령은 **서울 리전 CloudShell**에서 실행합니다.

| 언제 | 명령 | 하는 일 |
|---|---|---|
| 교육 전날 (사전 과제) | `bash ~/day2/setup/setup.sh user07 --check` | 사전 점검만: 자격 증명, EC2 vCPU 한도(8 이상), AZ, FIS, SLO 기능 준비, (모델 ID를 주면) Bedrock 호출 |
| 교육 당일 09:05 | `bash ~/day2/setup/setup.sh user07` | 점검 → 네트워크 `d2-shared` → 개발팀 서비스 `d2-user07` → 응답 확인 (약 6~8분) |
| 체크포인트마다 | `bash ~/day2/setup/status.sh user07` | 내 진도 한 줄 (경보 · SLO · 대시보드 · k6 · FIS · 평가) |
| 교육 종료 직후 | `bash ~/day2/setup/cleanup.sh user07` | 내 계정의 실습 리소스 모두 삭제 (`--dry-run`으로 목록만 볼 수 있음) |

- `user07` 자리에 명단의 내 번호를 씁니다. 리소스 이름과 `Owner` 태그에 쓰입니다.
- Bedrock 점검: `TARGET_MODEL=<ID> JUDGE_MODEL=<ID> bash ~/day2/setup/setup.sh user07 --check`
- `setup.sh`는 "개발팀이 배포해 둔 서비스"를 만드는 준비 작업입니다. 실습에서 만드는 경보 · SLO · 대시보드 · k6 · FIS 실험 · 게이트는 가이드를 보며 직접 입력합니다.
- 여러 번 실행해도 안전합니다. 실패한 스택(`ROLLBACK_COMPLETE`)은 지우고 다시 만듭니다.
- 루트 사용자로 접속해도 실습은 됩니다. 루트 액세스 키는 만들지 말고, 루트에 MFA를 켜 두세요.

| 파일 | 내용 |
|---|---|
| `d2-shared.yaml` | VPC 10.30.0.0/16, 퍼블릭 서브넷 2개(2 AZ), IGW |
| `d2-user-service.yaml` | ALB · ASG(2~4대, CPU 50% 대상 추적) · 콜드 스타트 앱 · 내 인스턴스만 다루는 FIS 역할 |
