#!/usr/bin/env bash
# Day 2 v2 — 내 실습 진행 상황 한 줄 (읽기 전용 명령만 사용)
#   bash ~/day2/setup/status.sh user07      (ME 변수가 있으면 인자 생략 가능)
# 체크포인트마다 실행해 마지막 '진도' 줄을 강사에게 보여 주거나 진도표에 적습니다.
set -uo pipefail
export AWS_REGION=ap-northeast-2 AWS_DEFAULT_REGION=ap-northeast-2
ME=${1:-${ME:-}}
[[ "$ME" =~ ^user[0-9]{2}$ ]] || { echo "사용법: bash ~/day2/setup/status.sh user07"; exit 1; }

mark() { (( $1 )) && echo "✔" || echo "·"; }

ST=$(aws cloudformation describe-stacks --stack-name "d2-$ME" --query "Stacks[0].StackStatus" --output text 2>/dev/null || echo NONE)
HL=0; SC=0
if [[ "$ST" != "NONE" ]]; then
  TGA=$(aws cloudformation describe-stacks --stack-name "d2-$ME" \
          --query "Stacks[0].Outputs[?OutputKey=='TargetGroupArn'].OutputValue" --output text 2>/dev/null)
  [[ -n "$TGA" && "$TGA" != "None" ]] && HL=$(aws elbv2 describe-target-health --target-group-arn "$TGA" \
          --query "length(TargetHealthDescriptions[?TargetHealth.State=='healthy'])" --output text 2>/dev/null || echo 0)
  SC=$(aws autoscaling describe-scheduled-actions --auto-scaling-group-name "d2-$ME-asg" \
          --query "length(ScheduledUpdateGroupActions)" --output text 2>/dev/null || echo 0)
fi
AL=$(aws cloudwatch describe-alarms --alarm-name-prefix "d2-$ME-" --query "length(MetricAlarms)" --output text 2>/dev/null || echo 0)
SL=$(aws application-signals list-service-level-objectives \
       --query "length(SloSummaries[?starts_with(Name,'d2-$ME-')])" --output text 2>/dev/null || echo 0)
DA=$(aws cloudwatch list-dashboards --dashboard-name-prefix "d2-$ME-" --query "length(DashboardEntries)" --output text 2>/dev/null || echo 0)
# 내 계정에는 내 실험만 있으므로 계정 전체를 셉니다
TP=$(aws fis list-experiment-templates --query "length(experimentTemplates)" --output text 2>/dev/null || echo 0)
EX=$(aws fis list-experiments --query "length(experiments[?state.status=='completed'])" --output text 2>/dev/null || echo 0)
K6=0; [[ -x "$HOME/bin/k6" && -f "$HOME/day2/lab2/load.js" ]] && K6=1
EV=0; ls "$HOME"/day2/lab4/out/judged_*.jsonl >/dev/null 2>&1 && EV=1

printf '%-7s %-16s 정상대상 %s · 경보 %s · SLO %s · 대시보드 %s · k6 %s · FIS템플릿 %s · 완료실험 %s · 예약조정 %s\n' \
  "$ME" "${ST:0:16}" "$HL" "$AL" "$SL" "$DA" "$(mark $K6)" "$TP" "$EX" "$SC"
echo "진도  ① $(mark $(( AL>=2 && SL>=2 && DA>=1 )))  ② $(mark $K6)  ③ $(mark $(( TP>=1 && EX>=1 )))  ④ $(mark $EV)   ($(date '+%H:%M') · 계정 $(aws sts get-caller-identity --query Account --output text 2>/dev/null))"
