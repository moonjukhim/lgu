# samples — 교육용 예시 데이터

이 폴더의 답변과 채점은 **실제 모델 출력이 아니라 강의 준비용으로 사람이 작성한 예시**다.

- `answers_v2.jsonl`: 실습 2단계(사람 채점 5건)에서 읽고 채점할 답변. Q02 · Q07 · Q08 · Q11 · Q12를 rubric.md로 채점해 human_scores.csv에 적는다.
- `judged_*.jsonl`: Bedrock을 쓸 수 없는 환경에서 `python3 run_eval.py report --offline` 으로 리포트 구조를 익히기 위한 예시 채점.
- 실제 모델로 돌리면 답변과 점수는 이 예시와 다르게 나온다. 그 차이를 비교하는 것도 좋은 토의 재료다.
