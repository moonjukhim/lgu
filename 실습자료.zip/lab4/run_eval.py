"""Day 2 v2 · 실습④ — LLM-as-a-Judge 프롬프트 회귀 평가 도구

이 도구는 실습에서 손으로 한 번 실행한 `aws bedrock-runtime converse` 호출을
평가셋 12문항 × 버전 2개에 대해 반복할 뿐입니다. API도 같습니다(boto3 bedrock-runtime.converse).

  python3 run_eval.py generate --version v1     # 대상 모델로 답변 생성  → out/answers_v1.jsonl
  python3 run_eval.py generate --version v2
  python3 run_eval.py judge --version v1        # Judge 모델로 채점      → out/judged_v1.jsonl
  python3 run_eval.py judge --version v2
  python3 run_eval.py report                    # 게이트 판정 리포트     → out/report.md
  python3 run_eval.py report --offline          # Bedrock 없이 samples/ 예시로 리포트

환경 변수
  TARGET_MODEL  평가 대상 챗봇 모델 ID (강사 공지, offline 외 필수)
  JUDGE_MODEL   Judge 모델 ID         (강사 공지, offline 외 필수)
  AWS_REGION    기본 ap-northeast-2
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = HERE / "out"
SAMPLES = HERE / "samples"
REGION = os.environ.get("AWS_REGION", "ap-northeast-2")
TARGET_MODEL = os.environ.get("TARGET_MODEL", "")
JUDGE_MODEL = os.environ.get("JUDGE_MODEL", "")

# ── 게이트 기준 (T5 슬라이드 「회귀 리포트와 게이트」) ──
GATE = {
    "min_accuracy": 4.0,      # v2 평균 정확성
    "max_grounded_fail": 0,   # 환각 FAIL 건수
    "max_policy_fail": 0,     # 정책 위반 FAIL 건수
    "max_regressions": 0,     # v1 대비 정확성 2점 이상 하락 문항 수
    "min_agreement": 0.8,     # Judge-사람 일치율 (정확성·완결성·어조 ±1점 이내)
}
CAT_ORDER = ["정상", "계산", "정보없음", "정책", "복합"]


# ───────────────────────────── 공통 ─────────────────────────────
def load_jsonl(p: Path) -> list[dict]:
    return [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]


def save_jsonl(p: Path, rows: list[dict]) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in rows), encoding="utf-8")


def read(name: str) -> str:
    return (HERE / name).read_text(encoding="utf-8")


def need_model(name: str, value: str) -> str:
    if not value:
        sys.exit(f"환경 변수 {name}가 비어 있습니다. 강사가 공지한 모델 ID로 export {name}=... 를 먼저 실행하세요.")
    return value


def bedrock():
    try:
        import boto3
        from botocore.config import Config
    except ImportError:
        sys.exit("boto3가 없습니다. pip3 install --user boto3 를 실행하세요.")
    return boto3.client("bedrock-runtime", region_name=REGION,
                        config=Config(retries={"max_attempts": 6, "mode": "adaptive"}, read_timeout=120))


def converse(client, model: str, system: str, user: str, max_tokens: int) -> str:
    """실습에서 손으로 친 aws bedrock-runtime converse 와 같은 호출."""
    last = None
    for i in range(3):
        try:
            r = client.converse(
                modelId=model,
                system=[{"text": system}],
                messages=[{"role": "user", "content": [{"text": user}]}],
                inferenceConfig={"maxTokens": max_tokens, "temperature": 0},
            )
            blocks = r["output"]["message"]["content"]
            return "".join(b.get("text", "") for b in blocks).strip()
        except Exception as e:  # 실습장 동시 접속 대비 재시도
            last = e
            code = getattr(e, "response", {}).get("Error", {}).get("Code", type(e).__name__)
            if code in ("AccessDeniedException", "ValidationException", "ResourceNotFoundException"):
                sys.exit(f"✗ {model}: {code} — 모델 ID · 리전 · 권한을 강사에게 확인하세요.\n  {e}")
            wait = 5 * (i + 1)
            print(f"  · 일시 오류({code}) — {wait}초 후 재시도")
            time.sleep(wait)
    raise SystemExit(f"✗ 3회 재시도 실패: {last}")


# ───────────────────────────── generate ─────────────────────────────
def cmd_generate(args) -> None:
    model = need_model("TARGET_MODEL", TARGET_MODEL)
    p = HERE / "prompts" / f"{args.version}.txt"
    if not p.exists():
        sys.exit(f"프롬프트 파일이 없습니다: {p}")
    system = p.read_text(encoding="utf-8").replace("{KB}", read("kb.md"))
    items = load_jsonl(HERE / "eval_set.jsonl")
    c = bedrock()

    def one(it):
        t0 = time.time()
        ans = converse(c, model, system, it["question"], 800)
        print(f"  ✓ {it['id']}")
        return {"id": it["id"], "version": args.version, "model": model, "answer": ans,
                "latency_s": round(time.time() - t0, 2)}

    print(f"▶ {args.version}: {len(items)}문항 답변 생성 ({model}, {REGION})")
    with ThreadPoolExecutor(max_workers=4) as ex:
        rows = list(ex.map(one, items))
    out = OUT / f"answers_{args.version}.jsonl"
    save_jsonl(out, rows)
    print(f"  → {out.relative_to(HERE)}")


# ───────────────────────────── judge ─────────────────────────────
JUDGE_SYSTEM = """당신은 통신사 요금 안내 챗봇의 품질 평가자입니다.
아래 <루브릭>에 따라 <기준문서>와 비교하여 챗봇 답변 하나를 채점합니다.

규칙:
- 먼저 판단 근거(reasoning)를 쓰고, 그다음 점수를 정합니다. 근거에는 기준 문서의 어느 내용과 비교했는지 씁니다.
- 답변의 길이나 말투의 친절함만으로 정확성 · 완결성 점수를 올리지 않습니다.
- key_points 중 답변에 없는 항목은 missed_points에 그대로 적습니다.
- must_not 항목에 해당하면 policy는 FAIL입니다. 기준 문서에 없는 내용을 사실처럼 안내하면 grounded는 FAIL입니다.
- 점수는 정수 1~5만 사용합니다.

출력 형식: 아래 키를 가진 JSON 객체 하나만 출력합니다. 다른 글은 쓰지 않습니다.
{"reasoning": "...", "accuracy": 1-5, "completeness": 1-5, "tone": 1-5,
 "grounded": "PASS|FAIL", "policy": "PASS|FAIL", "missed_points": ["..."]}

<루브릭>
{RUBRIC}
</루브릭>

<기준문서>
{KB}
</기준문서>"""


def clamp(v) -> int:
    try:
        return max(1, min(5, int(v)))
    except (TypeError, ValueError):
        return 1


def parse_judge(text: str) -> dict:
    """```json 블록, 앞뒤 설명 글이 섞여도 첫 JSON 객체를 꺼낸다."""
    m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.S)
    cand = m.group(1) if m else text[text.find("{"): text.rfind("}") + 1]
    j = json.loads(cand)
    for k in ("accuracy", "completeness", "tone"):
        j[k] = clamp(j.get(k))
    for k in ("grounded", "policy"):
        j[k] = "FAIL" if str(j.get(k, "")).strip().upper() == "FAIL" else "PASS"
    j.setdefault("reasoning", "")
    j.setdefault("missed_points", [])
    return j


def cmd_judge(args) -> None:
    model = need_model("JUDGE_MODEL", JUDGE_MODEL)
    src = OUT / f"answers_{args.version}.jsonl"
    if not src.exists():
        sys.exit(f"답변 파일이 없습니다: {src.relative_to(HERE)} — 먼저 generate --version {args.version} 를 실행하세요.")
    answers = {a["id"]: a for a in load_jsonl(src)}
    items = load_jsonl(HERE / "eval_set.jsonl")
    system = JUDGE_SYSTEM.replace("{RUBRIC}", read("rubric.md")).replace("{KB}", read("kb.md"))
    c = bedrock()

    def one(it):
        a = answers[it["id"]]
        user = "다음 답변을 채점하세요.\n" + json.dumps(
            {"question": it["question"], "category": it["category"], "key_points": it["key_points"],
             "must_not": it["must_not"], "chatbot_answer": a["answer"]}, ensure_ascii=False, indent=1)
        j = None
        for i in range(3):
            text = converse(c, model, system, user, 1500)
            try:
                j = parse_judge(text)
                break
            except (ValueError, json.JSONDecodeError):
                print(f"  · {it['id']} JSON 해석 실패 — 재시도 {i + 1}/3")
        if j is None:
            j = {"reasoning": "[Judge 출력 해석 실패 — 사람 검토 필요]", "accuracy": 1, "completeness": 1,
                 "tone": 1, "grounded": "FAIL", "policy": "FAIL", "missed_points": it["key_points"]}
        print(f"  ✓ {it['id']}  정확성 {j['accuracy']} · 완결성 {j['completeness']} · 근거 {j['grounded']} · 정책 {j['policy']}")
        return {"id": it["id"], "category": it["category"], "version": args.version, "judge_model": model, **j}

    print(f"▶ {args.version}: {len(items)}개 답변 채점 ({model})")
    with ThreadPoolExecutor(max_workers=4) as ex:
        rows = list(ex.map(one, items))
    out = OUT / f"judged_{args.version}.jsonl"
    save_jsonl(out, rows)
    print(f"  → {out.relative_to(HERE)}")


# ───────────────────────────── report ─────────────────────────────
def mean(xs):
    xs = list(xs)
    return round(sum(xs) / len(xs), 2) if xs else 0.0


def summarize(rows):
    return {"n": len(rows),
            "accuracy": mean(r["accuracy"] for r in rows),
            "completeness": mean(r["completeness"] for r in rows),
            "tone": mean(r["tone"] for r in rows),
            "grounded_fail": sum(r["grounded"] == "FAIL" for r in rows),
            "policy_fail": sum(r["policy"] == "FAIL" for r in rows)}


def agreement(judged):
    """human_scores.csv 중 입력된 행만 사용. 정확성 · 완결성 · 어조가 ±1점 이내면 일치."""
    p = HERE / "human_scores.csv"
    if not p.exists():
        return None, []
    hits = total = 0
    rows = []
    for h in csv.DictReader(p.open(encoding="utf-8-sig")):
        j = judged.get(h.get("version", ""), {}).get(h.get("id", ""))
        if not j or not (h.get("accuracy") or "").strip():
            continue
        line = {"id": h["id"], "version": h["version"]}
        for k in ("accuracy", "completeness", "tone"):
            try:
                hv = int(h[k])
            except (TypeError, ValueError):
                line[k] = "-"
                continue
            ok = abs(hv - j[k]) <= 1
            hits += ok
            total += 1
            line[k] = f"{hv} / {j[k]}" + ("" if ok else " ✗")
        for k in ("grounded", "policy"):  # 참고 표시만 (일치율에는 넣지 않음)
            hv = (h.get(k) or "").strip().upper() or "-"
            line[k] = f"{hv} / {j[k]}" + ("" if hv in ("-", j[k]) else " ✗")
        rows.append(line)
    return (round(hits / total, 2) if total else None), rows


def cmd_report(args) -> None:
    src = SAMPLES if args.offline else OUT
    base, cand = "v1", "v2"
    judged = {}
    for v in (base, cand):
        f = src / f"judged_{v}.jsonl"
        if not f.exists():
            sys.exit(f"채점 결과가 없습니다: {f.relative_to(HERE)} — 먼저 judge --version {v} 를 실행하거나 --offline 을 쓰세요.")
        judged[v] = {r["id"]: r for r in load_jsonl(f)}
    S = {v: summarize(list(judged[v].values())) for v in judged}

    cats = sorted({r["category"] for r in judged[base].values()},
                  key=lambda c: CAT_ORDER.index(c) if c in CAT_ORDER else 99)
    by_cat = {v: {c: mean(r["accuracy"] for r in judged[v].values() if r["category"] == c) for c in cats}
              for v in judged}

    regs = []
    for qid, b in judged[base].items():
        c = judged[cand].get(qid)
        if c and b["accuracy"] - c["accuracy"] >= 2:
            regs.append((qid, c["category"], f"정확성 {b['accuracy']}→{c['accuracy']}", c.get("reasoning", "")))

    agr, agr_rows = agreement(judged)
    sc = S[cand]
    checks = [
        ("평균 정확성", f"≥ {GATE['min_accuracy']}", sc["accuracy"], sc["accuracy"] >= GATE["min_accuracy"]),
        ("환각(근거 충실성) FAIL", f"≤ {GATE['max_grounded_fail']}건", sc["grounded_fail"],
         sc["grounded_fail"] <= GATE["max_grounded_fail"]),
        ("정책 위반 FAIL", f"≤ {GATE['max_policy_fail']}건", sc["policy_fail"], sc["policy_fail"] <= GATE["max_policy_fail"]),
        ("회귀 문항 (정확성 2점↓)", f"≤ {GATE['max_regressions']}건", len(regs), len(regs) <= GATE["max_regressions"]),
    ]
    if agr is not None:
        checks.append(("Judge-사람 일치율", f"≥ {GATE['min_agreement']:.0%}", f"{agr:.0%}", agr >= GATE["min_agreement"]))
    failed = [n for n, _, _, ok in checks if not ok]
    verdict = "PASS" if not failed else "FAIL"
    reason = "모든 게이트 통과" if not failed else ", ".join(failed) + " 미달"

    judge_name = next(iter(judged[cand].values())).get("judge_model", JUDGE_MODEL)
    L = [f"# 프롬프트 회귀 리포트 — {base} → {cand}", ""]
    if args.offline:
        L += ["> ⚠ --offline: samples/의 **교육용 예시 답변 · 예시 채점**으로 만든 리포트입니다. 실제 모델 결과가 아닙니다.", ""]
    L += [f"- 평가셋: eval_set.jsonl {S[base]['n']}문항 · 루브릭: rubric.md",
          f"- 대상 모델: {'예시 답변(samples/)' if args.offline else TARGET_MODEL or '-'} · Judge 모델: {judge_name}", "",
          "## ① 버전별 요약", "", "| 버전 | 정확성 | 완결성 | 어조 | 환각 FAIL | 정책 FAIL |", "|---|---|---|---|---|---|"]
    L += [f"| {v} | {S[v]['accuracy']} | {S[v]['completeness']} | {S[v]['tone']} | {S[v]['grounded_fail']} | {S[v]['policy_fail']} |"
          for v in judged]
    L += ["", "## ② 유형별 평균 정확성", "", "| 버전 | " + " | ".join(cats) + " |", "|---|" + "---|" * len(cats)]
    L += [f"| {v} | " + " | ".join(str(by_cat[v][c]) for c in cats) + " |" for v in judged]
    L += ["", f"## ③ 회귀 문항 ({base} 대비 {cand}, 정확성 2점 이상 하락)", ""]
    if not regs:
        L += ["회귀 문항 없음"]
    else:
        L += ["| 문항 | 유형 | 변화 | Judge 근거 |", "|---|---|---|---|"]
        L += [f"| {q} | {c} | {w} | {r.replace('|', '/')[:160]} |" for q, c, w, r in regs]
    L += ["", "## ④ Judge-사람 일치율", ""]
    if agr is None:
        L += ["human_scores.csv에 사람 채점이 없습니다 (일치율 미산출 — 게이트에서 제외)."]
    else:
        L += [f"일치율 **{agr:.0%}** (정확성 · 완결성 · 어조가 ±1점 이내면 일치) — 표기: 사람 / Judge, ✗ = 불일치", "",
              "| 문항 | 버전 | 정확성 | 완결성 | 어조 | 근거(참고) | 정책(참고) |", "|---|---|---|---|---|---|---|"]
        L += [f"| {r['id']} | {r['version']} | {r['accuracy']} | {r['completeness']} | {r['tone']} | {r['grounded']} | {r['policy']} |"
              for r in agr_rows]
    L += ["", f"## ⑤ 게이트 판정 — {cand}", "", "| 기준 | 게이트 | 측정값 | 결과 |", "|---|---|---|---|"]
    L += [f"| {n} | {g} | {m} | {'✓' if ok else '✗'} |" for n, g, m, ok in checks]
    L += ["", f"**v2 배포 판정: {verdict} ({reason})**", "",
          "판정 문장 틀: “평가셋 __문항 기준 평균 정확성 __→__, 환각 __건, 정책 __건, 회귀 __건 → [PASS/FAIL]. "
          "원인 추정: __. 다음 행동: __. 되물을 질문: __”"]

    OUT.mkdir(exist_ok=True)
    out = OUT / "report.md"
    out.write_text("\n".join(L) + "\n", encoding="utf-8")

    print(f"▶ 프롬프트 회귀 리포트 {base} → {cand}" + ("  (offline 예시)" if args.offline else ""))
    for v in judged:
        s = S[v]
        print(f"  {v}: 정확성 {s['accuracy']} · 완결성 {s['completeness']} · 어조 {s['tone']} · "
              f"환각 FAIL {s['grounded_fail']} · 정책 FAIL {s['policy_fail']}")
    print("  유형별 정확성 " + " / ".join(f"{c} {by_cat[base][c]}→{by_cat[cand][c]}" for c in cats))
    print("  회귀 문항: " + (", ".join(f"{q}({w})" for q, _, w, _ in regs) or "없음"))
    for n, g, m, ok in checks:
        print(f"  {'✓' if ok else '✗'} {n}: {m} (게이트 {g})")
    print(f"\nv2 배포 판정: {verdict} ({reason})   — 전체 리포트: {out.relative_to(HERE)}")


# ───────────────────────────── main ─────────────────────────────
def main() -> None:
    ap = argparse.ArgumentParser(description="LLM-as-a-Judge 프롬프트 회귀 평가 (boto3 converse)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name, fn in (("generate", cmd_generate), ("judge", cmd_judge)):
        p = sub.add_parser(name)
        p.add_argument("--version", required=True, choices=["v1", "v2", "v3"])
        p.set_defaults(fn=fn)
    p = sub.add_parser("report")
    p.add_argument("--offline", action="store_true", help="samples/의 예시 채점으로 리포트")
    p.set_defaults(fn=cmd_report)
    args = ap.parse_args()
    args.fn(args)


if __name__ == "__main__":
    main()
