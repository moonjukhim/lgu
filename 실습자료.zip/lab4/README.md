# 실습④ LLM-as-a-Judge — 자료 폴더

| 파일 | 내용 | 직접 고치나 |
|---|---|---|
| `kb.md` | 가상 통신사 「가온모바일」 요금제 · 할인 기준 문서 (**가상 데이터**) | — |
| `prompts/v1.txt` · `v2.txt` | 챗봇 시스템 프롬프트. `{KB}` 자리에 기준 문서가 들어간다. v2는 기획팀 개선 요청 3줄이 추가된 버전 | v3 만들기 (선택) |
| `eval_set.jsonl` | 평가 문항 12개 (질문 · 유형 · 기대 핵심 사항 · 금지 사항) | 문항 추가 (선택) |
| `rubric.md` | 사람과 Judge가 함께 쓰는 채점 기준 | 토의 후 수정 (선택) |
| `human_scores.csv` | 사람 채점 5행 (Q02 · Q07 · Q08 · Q11 · Q12, v2) | **직접 입력** |
| `run_eval.py` | 손으로 한 `converse` 호출을 24번 반복하는 도구 (boto3) | — |
| `samples/` | Bedrock을 쓸 수 없을 때 쓰는 **사람이 작성한 예시** 답변 · 채점 | — |

## 순서 (자세한 설명은 실습 가이드)

```bash
cd ~/day2/lab4
export TARGET_MODEL=<강사 공지>   JUDGE_MODEL=<강사 공지>
# 손으로 한 번: 실습 가이드의 jq + aws bedrock-runtime converse 명령
python3 run_eval.py generate --version v1
python3 run_eval.py generate --version v2
python3 run_eval.py judge --version v1
python3 run_eval.py judge --version v2
python3 run_eval.py report            # → out/report.md, 마지막 줄 "v2 배포 판정: PASS/FAIL (사유)"
python3 run_eval.py report --offline  # Bedrock 없이 samples/ 예시로
```

- 결과 파일: `out/answers_v1.jsonl`, `out/answers_v2.jsonl`, `out/judged_v1.jsonl`, `out/judged_v2.jsonl`, `out/report.md`
- 게이트: v2 평균 정확성 ≥ 4.0 · 환각 FAIL 0건 · 정책 FAIL 0건 · v1 대비 정확성 2점 이상 하락 0문항 · Judge-사람 일치율(정확성 · 완결성 · 어조 ±1점) ≥ 80%
- 사람 채점을 하지 않았으면 일치율은 게이트에서 빠진다.
- boto3가 없다는 메시지가 나오면 `pip3 install --user boto3`
