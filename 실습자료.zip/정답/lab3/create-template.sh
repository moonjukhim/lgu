#!/bin/bash
# 실습③ 콘솔 대신 CLI로 실험 템플릿 만들기 (따라잡기용)
#   bash create-template.sh 1   → 실험1 인스턴스 종료
#   bash create-template.sh 2   → 실험2 CPU 스트레스
# JSON 파일의 __ME__ · __FIS_ROLE__ · __STOP_ALARM_ARN__ 자리를 내 값으로 바꿔 넣고 만듭니다.
set -euo pipefail
source ~/day2.env
cd "$(dirname "$0")"
case "${1:-1}" in
  1) SRC=exp1-terminate.json ;;
  2) SRC=exp2-cpu.json ;;
  *) echo "1 또는 2를 입력하세요"; exit 1 ;;
esac
STOP_ALARM_ARN=$(aws cloudwatch describe-alarms --alarm-names d2-$ME-stop-5xx \
  --query "MetricAlarms[0].AlarmArn" --output text)
if [ -z "$STOP_ALARM_ARN" ] || [ "$STOP_ALARM_ARN" = "None" ]; then
  echo "중지 조건 경보 d2-$ME-stop-5xx 가 없습니다. 실습① D-1을 먼저 하세요"; exit 1
fi
sed -e "s|__ME__|$ME|g" -e "s|__FIS_ROLE__|$FIS_ROLE|g" -e "s|__STOP_ALARM_ARN__|$STOP_ALARM_ARN|g" \
  "$SRC" > /tmp/d2-exp.json
echo "== 만들 템플릿 (읽어 보고 확인하세요)"; cat /tmp/d2-exp.json
aws fis create-experiment-template --cli-input-json file:///tmp/d2-exp.json \
  --query "experimentTemplate.id" --output text
