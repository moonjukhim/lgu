#!/bin/bash
# 실습③ 안전 확인 → 실험 시작 → 15초 간격 관찰 (따라잡기용)
#   bash run-observe.sh <템플릿ID>      관찰을 끝내려면 Ctrl+C (실험은 계속됨)
#   비상 중지: aws fis stop-experiment --id <실험ID>
source ~/day2.env
TPL=${1:?템플릿 ID를 인자로 주세요 (aws fis list-experiment-templates 로 확인)}

echo "== 안전 확인"
aws cloudwatch describe-alarms --alarm-names d2-$ME-stop-5xx \
  --query "MetricAlarms[0].StateValue" --output text
aws elbv2 describe-target-health --target-group-arn $TG_ARN \
  --query "TargetHealthDescriptions[].[Target.Id,TargetHealth.State]" --output table
aws fis list-experiments \
  --query "experiments[?tags.Owner=='$ME'].[id,state.status]" --output table

read -r -p "대상은 내 인스턴스, 중지 경보 OK, 정상 대상 2대, 실행 중 실험 없음 — 시작할까요? [y/N] " ok
[ "$ok" = "y" ] || { echo "취소"; exit 0; }

export EXP1=$(aws fis start-experiment --experiment-template-id $TPL \
  --tags Owner=$ME --query "experiment.id" --output text)
echo $EXP1 ; date +%H:%M:%S

while true; do
  echo "---- $(date +%H:%M:%S)"
  aws fis get-experiment --id $EXP1 --query "experiment.state" --output table
  aws elbv2 describe-target-health --target-group-arn $TG_ARN \
    --query "TargetHealthDescriptions[].[Target.Id,TargetHealth.State]" --output table
  aws autoscaling describe-scaling-activities --auto-scaling-group-name $ASG --max-items 3 \
    --query "Activities[].[StartTime,StatusCode,Description]" --output table
  sleep 15
done
