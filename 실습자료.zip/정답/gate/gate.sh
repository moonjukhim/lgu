#!/bin/bash
# 에러버짓 + 스모크 부하 게이트: 둘 다 통과해야 배포 승인
source ~/day2.env
export PATH=$HOME/bin:$PATH
STATUS=$(aws application-signals batch-get-service-level-objective-budget-report \
  --timestamp $(date -u +%Y-%m-%dT%H:%M:%SZ) --slo-ids $SLO_AVAIL \
  --query "Reports[0].BudgetStatus" --output text)
echo "가용성 SLO 버짓 상태: $STATUS"
if [ "$STATUS" = "BREACHED" ]; then
  echo "FAIL: 에러버짓 소진 — 배포 중단 (안정화 작업 우선)"; exit 1
fi
k6 run -e BASE_URL=$BASE_URL --vus 5 --duration 60s ~/day2/lab2/load.js --quiet
if [ $? -ne 0 ]; then
  echo "FAIL: 스모크 부하 기준 미달 — 배포 중단"; exit 1
fi
echo "PASS: 배포 승인"
