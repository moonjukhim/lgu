#!/bin/bash
# 실습② 선택 과제 — 2분 뒤 4대로 미리 늘리고, 20분 뒤 2대로 되돌립니다.
source ~/day2.env

aws autoscaling put-scheduled-update-group-action --auto-scaling-group-name $ASG \
  --scheduled-action-name d2-$ME-prewarm \
  --start-time $(date -u -d '+2 min' +%Y-%m-%dT%H:%M:%SZ) \
  --min-size 4 --desired-capacity 4
aws autoscaling put-scheduled-update-group-action --auto-scaling-group-name $ASG \
  --scheduled-action-name d2-$ME-restore \
  --start-time $(date -u -d '+20 min' +%Y-%m-%dT%H:%M:%SZ) \
  --min-size 2 --desired-capacity 2

aws autoscaling describe-scheduled-actions --auto-scaling-group-name $ASG \
  --query "ScheduledUpdateGroupActions[].[ScheduledActionName,StartTime,MinSize,DesiredCapacity]" --output table
