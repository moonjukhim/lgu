#!/bin/bash
# 실습② 탭 2 관찰 명령 — 2~3분마다 다시 실행합니다.
source ~/day2.env

echo '== 확장 활동 (개발팀의 근거)'
aws autoscaling describe-scaling-activities   --auto-scaling-group-name $ASG --max-items 6 \
  --query "Activities[].[StartTime,EndTime,StatusCode,Description]" --output table

echo '== 분 단위 p95 (품질팀의 근거)'
aws cloudwatch get-metric-statistics   --namespace AWS/ApplicationELB --metric-name TargetResponseTime \
  --dimensions Name=LoadBalancer,Value=$ALB --extended-statistics p95 --period 60 \
  --start-time $(date -u -d '-20 min' +%Y-%m-%dT%H:%M:%SZ)   --end-time $(date -u +%Y-%m-%dT%H:%M:%SZ) \
  --query "sort_by(Datapoints,&Timestamp)[].[Timestamp,ExtendedStatistics.p95]"   --output table

echo '== 정상 대상'
aws elbv2 describe-target-health --target-group-arn $TG_ARN \
  --query "TargetHealthDescriptions[].[Target.Id,TargetHealth.State]" --output table
