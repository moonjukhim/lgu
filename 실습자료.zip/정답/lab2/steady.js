import http from 'k6/http';
import { check, sleep } from 'k6';

const BASE_URL = __ENV.BASE_URL;

export const options = {
  stages: [
    { duration: '2m', target: 30 },
    { duration: '50m', target: 30 },
  ],
  thresholds: {
    http_req_failed: ['rate<0.005'],
    http_req_duration: ['p(95)<800'],
  },
};

export default function () {
  const res = http.get(`${BASE_URL}/bill?work=40`);
  check(res, {
    'status 200': (r) => r.status === 200,
    'warm instance': (r) => r.status === 200 && r.json('warm') === true,
  });
  sleep(0.5);
}
