# 실습① A-2 — 값은 반드시 내 스택 출력(A-1)으로 바꿉니다. 그대로 쓰면 동작하지 않습니다.
export ME=user07
export AWS_REGION=ap-northeast-2
export BASE_URL=http://d2-user07-alb-1234567890.ap-northeast-2.elb.amazonaws.com
export ASG=d2-user07-asg
export TG_ARN=arn:aws:elasticloadbalancing:ap-northeast-2:111122223333:targetgroup/d2-user07-tg/0123456789abcdef
export ALB=app/d2-user07-alb/0123456789abcdef
export TG=targetgroup/d2-user07-tg/0123456789abcdef
export FIS_ROLE=arn:aws:iam::111122223333:role/d2-user07-fis-role

# 저장 (A-3)
env | grep -E '^(AWS_REGION|ME|BASE_URL|ASG|TG_ARN|ALB|TG|FIS_ROLE)=' | sed 's/^/export /' > ~/day2.env
echo 'source ~/day2.env' >> ~/.bashrc
cat ~/day2.env
