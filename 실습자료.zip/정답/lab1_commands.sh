#!/bin/bash
# 실습① 명령 모음 — 필요한 줄만 복사해 실행합니다. (먼저 source ~/day2.env)

# A-1. 내 스택 출력값
aws cloudformation describe-stacks --stack-name d2-$ME \
  --query "Stacks[0].Outputs[].[OutputKey,OutputValue]" --output table

# B-1. ASG 설정
aws autoscaling describe-auto-scaling-groups \
  --auto-scaling-group-names $ASG \
  --query "AutoScalingGroups[0].{min:MinSize, max:MaxSize,
     desired:DesiredCapacity, hc:HealthCheckType,
     grace:HealthCheckGracePeriod, warmup:DefaultInstanceWarmup,
     azs:AvailabilityZones}"

# B-2. 조정 정책
aws autoscaling describe-policies \
  --auto-scaling-group-name $ASG \
  --query "ScalingPolicies[].{name:PolicyName, type:PolicyType,
     target:TargetTrackingConfiguration.TargetValue,
     metric:TargetTrackingConfiguration.PredefinedMetricSpecification.PredefinedMetricType}"

# B-3. 대상 그룹 헬스체크
aws elbv2 describe-target-groups \
  --target-group-arns $TG_ARN \
  --query "TargetGroups[0].{path:HealthCheckPath,
     interval:HealthCheckIntervalSeconds,
     healthy:HealthyThresholdCount, unhealthy:UnhealthyThresholdCount}"

# B-4. 정상 대상
aws elbv2 describe-target-health --target-group-arn $TG_ARN \
  --query "TargetHealthDescriptions[].[Target.Id,TargetHealth.State]" --output table

# B-5. 서비스 응답 · 준비 상태
curl -s $BASE_URL/bill ; echo
curl -s -o /dev/null -w "%{http_code}\n" $BASE_URL/ready

# C-1. ALB 지표 목록
aws cloudwatch list-metrics --namespace AWS/ApplicationELB \
  --dimensions Name=LoadBalancer,Value=$ALB --query "Metrics[].MetricName" --output text

# D-1. FIS 중지 조건 경보
aws cloudwatch put-metric-alarm \
  --alarm-name d2-$ME-stop-5xx \
  --namespace AWS/ApplicationELB \
  --metric-name HTTPCode_ELB_5XX_Count \
  --dimensions Name=LoadBalancer,Value=$ALB \
  --statistic Sum --period 60 \
  --evaluation-periods 1 --threshold 50 \
  --comparison-operator GreaterThanOrEqualToThreshold \
  --treat-missing-data notBreaching

# D-2. 지연 경보
aws cloudwatch put-metric-alarm \
  --alarm-name d2-$ME-p95-slow \
  --namespace AWS/ApplicationELB \
  --metric-name TargetResponseTime \
  --dimensions Name=LoadBalancer,Value=$ALB \
  --extended-statistic p95 --period 60 \
  --evaluation-periods 3 --datapoints-to-alarm 3 --threshold 0.8 \
  --comparison-operator GreaterThanThreshold \
  --treat-missing-data notBreaching

# D-3. 경보 확인
aws cloudwatch describe-alarms --alarm-name-prefix d2-$ME \
  --query "MetricAlarms[].[AlarmName,StateValue]" --output table

# E~G. SLO 2개 · 번레이트 경보 · 대시보드는 콘솔에서 만듭니다 (실습 가이드 표 참고)

# H-1. 내 SLO 목록
aws application-signals list-service-level-objectives \
  --query "SloSummaries[?starts_with(Name,'d2-$ME')].[Name,Arn]" --output table

# H-2. SLO ARN 저장
export SLO_AVAIL=$(aws application-signals list-service-level-objectives   --query "SloSummaries[?Name=='d2-$ME-avail'].Arn" --output text)
export SLO_LAT=$(aws application-signals list-service-level-objectives   --query "SloSummaries[?Name=='d2-$ME-latency'].Arn" --output text)
echo $SLO_AVAIL ; echo $SLO_LAT
echo "export SLO_AVAIL=$SLO_AVAIL" >> ~/day2.env
echo "export SLO_LAT=$SLO_LAT" >> ~/day2.env

# H-3. 버짓 리포트
aws application-signals batch-get-service-level-objective-budget-report \
  --timestamp $(date -u +%Y-%m-%dT%H:%M:%SZ) \
  --slo-ids $SLO_AVAIL $SLO_LAT \
  --query "Reports[].{name:Name, status:BudgetStatus, attain:Attainment,
     reqLeft:BudgetRequestsRemaining, reqTotal:TotalBudgetRequests,
     secLeft:BudgetSecondsRemaining, secTotal:TotalBudgetSeconds}" \
  --output table
