#!/bin/bash
# 실습④ 명령 모음 — 한 단계씩 복사해 실행합니다. (cd ~/day2/lab4 && source ~/day2.env)

# A-2. 모델 ID 확인 · 변수 (강사 공지 값으로 바꿉니다)
aws bedrock list-inference-profiles \
  --query "inferenceProfileSummaries[?contains(inferenceProfileId,'claude')].inferenceProfileId" --output table
# export TARGET_MODEL=<강사가 공지한 대상 모델 ID>
# export JUDGE_MODEL=<강사가 공지한 Judge 모델 ID>
# echo "export TARGET_MODEL=$TARGET_MODEL" >> ~/day2.env
# echo "export JUDGE_MODEL=$JUDGE_MODEL" >> ~/day2.env

# B-1. 시스템 프롬프트 파일
jq -n --rawfile p prompts/v1.txt --rawfile kb kb.md '[{text: ($p | sub("\\{KB\\}"; $kb))}]' > sys_v1.json
jq -n --rawfile p prompts/v2.txt --rawfile kb kb.md '[{text: ($p | sub("\\{KB\\}"; $kb))}]' > sys_v2.json
jq -r '.[0].text' sys_v2.json | tail -n 5

# B-2. v1 호출
aws bedrock-runtime converse --model-id $TARGET_MODEL \
  --system file://sys_v1.json \
  --messages '[{"role":"user","content":[{"text":"라이트 요금제 쓰는데 데이터 다 쓰면 어떻게 돼요?"}]}]' \
  --inference-config maxTokens=800,temperature=0 \
  --query "output.message.content[0].text" --output text | tee ans_v1_q02.txt

# B-3. v2 호출
aws bedrock-runtime converse --model-id $TARGET_MODEL \
  --system file://sys_v2.json \
  --messages '[{"role":"user","content":[{"text":"라이트 요금제 쓰는데 데이터 다 쓰면 어떻게 돼요?"}]}]' \
  --inference-config maxTokens=800,temperature=0 \
  --query "output.message.content[0].text" --output text | tee ans_v2_q02.txt

# C-1. 사람 채점 (human_scores.csv 를 nano 로 채웁니다)
cat rubric.md
jq -r 'select(.id | IN("Q02","Q07","Q08","Q11","Q12")) | "\(.id)  \(.answer)\n"' samples/answers_v2.jsonl
nano human_scores.csv

# D-1. Judge 메시지 만들기
jq -n --rawfile rubric rubric.md --rawfile kb kb.md --rawfile ans ans_v2_q02.txt \
  --slurpfile item <(jq -c 'select(.id=="Q02")' eval_set.jsonl) \
  '[{role:"user", content:[{text:
     ("<루브릭>\n" + $rubric + "</루브릭>\n<기준문서>\n" + $kb + "</기준문서>\n"
      + "<질문>" + $item[0].question + "</질문>\n"
      + "<기대핵심사항>" + ($item[0].key_points | join(" / ")) + "</기대핵심사항>\n"
      + "<답변>\n" + $ans + "</답변>\n"
      + "루브릭으로 채점하세요. 근거를 먼저 쓰고, 다음 형식의 JSON 하나만 출력하세요: "
      + "{\"reasoning\":\"...\",\"accuracy\":1-5,\"completeness\":1-5,\"tone\":1-5,\"grounded\":\"PASS|FAIL\",\"policy\":\"PASS|FAIL\"}")
  }]}]' > judge_q02.json
jq -r '.[0].content[0].text' judge_q02.json | tail -n 8

# D-2. Judge 호출
aws bedrock-runtime converse --model-id $JUDGE_MODEL \
  --messages file://judge_q02.json \
  --inference-config maxTokens=1500,temperature=0 \
  --query "output.message.content[0].text" --output text

# E-1. 전체 자동화
python3 run_eval.py generate --version v1
python3 run_eval.py generate --version v2
python3 run_eval.py judge --version v1
python3 run_eval.py judge --version v2
python3 run_eval.py report

# E-2. 리포트 읽기
less out/report.md

# Bedrock을 쓸 수 없을 때
python3 run_eval.py report --offline
