# 실습⑤ ★ (추가) AWS FIS API 장애 주입 + X-Ray 트레이스 (50분)

> 바탕: AWS 「Chaos Engineering / FIS workshop V2」 › 실험 › **API 실험**(API 스로틀링 · API 사용 불가) 모듈.
> 워크숍 구성(API Gateway → Lambda → EC2 API, SQS 비동기 경로)을 오늘 실습 방식(1인 1계정 · `d2-<ME>` 이름 · 중지 조건 · 직접 입력)에 맞게 다시 만들고, **X-Ray로 요청 안쪽까지 트레이스**하도록 했습니다.

## 0. 이번 실습의 이야기

개발팀이 요금 운영 도구 **bill-ops API**를 만들었습니다. 이 API는 내부에서 AWS의 **제어 평면 API**(EC2 `DescribeInstances` · `TerminateInstances`)를 부릅니다.

> 개발팀: "AWS API가 가끔 스로틀링을 걸어도 **SDK가 알아서 재시도**하니까 괜찮아요."

품질팀은 이 말을 FIS로 검증합니다. FIS는 **특정 IAM 역할(= Lambda 실행 역할)** 이 부르는 AWS API에만 오류를 주입합니다. 서비스 전체가 아니라 **내 Lambda만** 영향을 받으므로 폭발 반경이 아주 작습니다.

그리고 실습②·③에서는 ALB 지표(바깥)만 봤다면, 이번에는 **X-Ray 트레이스로 요청 하나의 안쪽**을 봅니다: API Gateway에서 몇 ms, Lambda에서 몇 ms, EC2 API 호출에서 몇 번 재시도하며 몇 ms를 썼는지.

```
[나: CloudShell] ─curl─▶ [API Gateway d2-<ME>-api (stage lab, X-Ray 켬)]
                           ├─ GET  /describe  ─▶ [Lambda d2-<ME>-api-app (X-Ray 켬)] ─▶ EC2 DescribeInstances
                           ├─ POST /terminate ─▶ [Lambda] ─▶ EC2 DescribeInstances → TerminateInstances (희생 인스턴스)
                           └─ POST /async     ─▶ [SQS d2-<ME>-api-queue] ─▶ [Lambda] ─▶ (실패하면 30초 뒤 재시도)

  FIS 실험 대상 = IAM 역할 d2-<ME>-api-lambda-role (aws:iam:role)
  FIS 실행 역할 = d2-<ME>-fis-api-role · 실험 로그 = /d2/<ME>/fis-api-experiments
  희생 인스턴스 = ASG d2-<ME>-api-victim-asg (1대). Owner 태그가 없어 실습③ 템플릿이 고를 수 없습니다
```

| 단계 | 내용 | 도구 | 시간 |
|---|---|---|---|
| A | 환경 배포 · 변수 저장 | CLI | 8분 |
| B | 정상 상태 측정 + X-Ray 트레이스 맵 | CLI · 콘솔 | 7분 |
| C | 중지 조건 경보 | CLI | 3분 |
| D | 실험3 API 스로틀링 → 재시도 늘려 다시 | 콘솔 · CLI | 17분 |
| E | 실험4 API 사용 불가 → 동기 vs 비동기 | 콘솔 · CLI | 12분 |
| F | 판정 | 워크시트 | 3분 |

산출물: 중지 조건 경보 1개, FIS 실험 템플릿 2개, 실험 3회(run1 · run2 · 사용 불가), X-Ray 근거 표, 판정 문장

> ⓘ 비용: Lambda · API Gateway · SQS · X-Ray는 실습량으로는 몇 센트 수준입니다. 희생 인스턴스 t3.micro 1대가 추가로 돕니다. 끝나면 `cleanup_v2.sh` 로 지웁니다.
> ⓘ vCPU: 희생 인스턴스가 vCPU 2개를 씁니다. 한도가 8이면 웹 ASG가 2대일 때(실습③ 이후) 진행합니다.

---

## A. 환경 배포 · 변수 저장 (8분)

### A-0. 새 자료 풀기 · API 실습 스택 배포

① 입력

```bash
unzip -n ~/Day2_v2_실습자료_v2.zip -d ~/day2
bash ~/day2/setup/setup_api_v2.sh $ME
```

② 옵션 풀이

| 옵션 · 부분 | 뜻 | 왜 이 값인가 |
|---|---|---|
| `unzip -n` | 이미 있는 파일은 **덮어쓰지 않고** 새 파일만 풉니다 | 실습④에서 채운 `human_scores.csv` 같은 내 파일을 지키기 위해서입니다 (`-o` 를 쓰지 않습니다) |
| `setup_api_v2.sh` | X-Ray SDK 레이어 만들기 → 스택 `d2-$ME-api` 배포 → 응답 확인 | 실습 내용이 아니라 ‘개발팀이 배포해 둔 상태’를 만드는 준비 작업입니다 |
| X-Ray SDK 레이어 | `aws-xray-sdk`를 Lambda 레이어로 올립니다 | SDK가 있어야 **EC2 API 호출 하나하나**가 트레이스에 구간으로 남습니다 |

③ 확인 ✅

```
═══ 2. X-Ray SDK 레이어 d2-user07-xray-sdk (약 30초)
  ✔ 레이어 게시: d2-user07-xray-sdk:1
═══ 3. API 실험 스택 d2-user07-api (약 3~4분)
  ✔ d2-user07-api CREATE_COMPLETE
═══ 4. 응답 확인
  ✔ GET https://abcd1234.execute-api.ap-northeast-2.amazonaws.com/lab/describe
      {"InstanceIds": ["i-0a1b...", "i-0f9e...", "i-07c3..."], "RetryAttempts": 0, ...}
  ✔ 희생 인스턴스: i-07c3d2e1f0a9b8c7d
```

✅ ‘준비 완료’가 나오면 됩니다. `△ pip 설치 실패 — SDK 없이 배포` 가 나와도 실습은 됩니다(트레이스에 EC2 구간만 빠짐). 강사에게 알립니다.

□ 완료 □ 막힘

### A-1. 스택 출력값 보기

① 입력

```bash
aws cloudformation describe-stacks --stack-name d2-$ME-api \
  --query "Stacks[0].Outputs[].[OutputKey,OutputValue]" --output table
```

③ 확인 ✅ — `ApiUrl · ApiName · AppFunctionName · AppRoleArn · FisApiRoleArn · FisLogGroupArn · QueueName · VictimAsgName · XRaySdk` 9개가 보이면 됩니다.

### A-2. 변수 만들기 · 저장 — 표의 값을 보고 직접 입력

① 입력 (예시의 user07 · 숫자는 내 값으로 바꿉니다)

```bash
export API_URL=https://abcd1234.execute-api.ap-northeast-2.amazonaws.com/lab
export API_NAME=d2-user07-api
export APP_FN=d2-user07-api-app
export APP_ROLE=arn:aws:iam::111122223333:role/d2-user07-api-lambda-role
export FIS_API_ROLE=arn:aws:iam::111122223333:role/d2-user07-fis-api-role
export FIS_API_LOG=arn:aws:logs:ap-northeast-2:111122223333:log-group:/d2/user07/fis-api-experiments:*
export QUEUE=d2-user07-api-queue
env | grep -E '^(API_URL|API_NAME|APP_FN|APP_ROLE|FIS_API_ROLE|FIS_API_LOG|QUEUE)=' | sed 's/^/export /' >> ~/day2.env
cd ~/day2/lab3_api
```

② 옵션 풀이

| 변수 | 출력값 | 쓰는 곳 |
|---|---|---|
| `API_URL` | ApiUrl | curl 이 요청을 보낼 곳. 끝에 `/` 를 붙이지 않습니다 |
| `API_NAME` | ApiName | 중지 조건 경보의 지표 차원(ApiName) |
| `APP_FN` | AppFunctionName | X-Ray 필터 `service("…")`, 재시도 설정 변경 |
| `APP_ROLE` | AppRoleArn | **FIS 실험 대상**(aws:iam:role). 이 역할이 부르는 API에만 장애가 들어갑니다 |
| `FIS_API_ROLE` | FisApiRoleArn | FIS가 실험을 실행할 때 쓰는 역할 |
| `FIS_API_LOG` | FisLogGroupArn | 실험 로그를 보낼 곳. 끝의 `:*` 까지 그대로 씁니다 |
| `QUEUE` | QueueName | 비동기 경로 큐 |
| `>> ~/day2.env` | 기존 변수 파일 **뒤에 덧붙입니다** | `>` 로 쓰면 실습①~④ 변수가 지워집니다 |

③ 확인 ✅ — `tail -n 7 ~/day2.env` 에 7줄이 보이면 됩니다.

□ 완료 □ 막힘

---

## B. 정상 상태 측정 + X-Ray 트레이스 맵 (7분)

### B-1. 한 번 호출해 보기

① 입력

```bash
curl -s $API_URL/describe
```

③ 확인 ✅ (값은 사람마다 다릅니다)

```json
{"InstanceIds": ["i-0a1b2c3d4e5f60718", "i-0f9e8d7c6b5a40321", "i-07c3d2e1f0a9b8c7d"], "RetryAttempts": 0, "ElapsedMs": 143,
 "MaxAttempts": 5, "RetryMode": "legacy", "TotalMs": 151, "TraceId": "1-6730a1b2-0123456789abcdef01234567"}
```

| 필드 | 뜻 |
|---|---|
| `RetryAttempts` | SDK가 EC2 API를 **다시 시도한 횟수**. 정상이면 0 |
| `ElapsedMs` | EC2 API 호출에 걸린 시간 (재시도 포함) |
| `MaxAttempts` · `RetryMode` | 지금 Lambda의 SDK 재시도 설정 (D-6에서 바꿉니다) |
| `TraceId` | 이 요청의 X-Ray 트레이스 ID. `bash trace-detail.sh <ID>` 로 펼쳐 봅니다 |

### B-2. 정상 상태 기준선 — 10회

① 입력

```bash
bash run-api-throttle.sh 10
```

③ 확인 ✅

```
#    시각     코드  총(ms)   EC2(ms)  재시도  결과 · 트레이스 ID
1    05:01:12 200   312      140      0       OK 3대 1-6730a1b2-...
...
──
성공 10 · 실패 0 · 최대 재시도 0 · 평균 290ms · 최대 420ms   (시각은 UTC)
```

✅ 성공 10 · 최대 재시도 0 을 기록지 「정상상태」 칸에 적습니다.

### B-3. X-Ray — 트레이스 맵과 요청 한 건 펼쳐 보기

① 입력 (요청 후 30초쯤 지나야 트레이스가 조회됩니다)

```bash
bash xray-traces.sh 10
bash trace-detail.sh
```

② 옵션 풀이

| 부분 | 뜻 | 왜 보나 |
|---|---|---|
| `xray-traces.sh` ① 요약 | 최근 트레이스 수와 오류(4xx) · 장애(5xx) · 스로틀(429) 수 | 고객 요청 중 몇 건이 문제였나 |
| ② `annotation.retry_attempts > 0` | Lambda 코드가 남긴 **주석(annotation)** 으로 거른 트레이스 | 재시도가 있었던 요청만 골라냅니다. 정상이면 비어 있습니다 |
| ④ 트레이스 맵 노드 | API Gateway · Lambda · **EC2** 노드별 호출 수 · 스로틀 · 평균 시간 | 시간이 **어느 구간**에서 쓰였는지 |
| `trace-detail.sh` | 트레이스 1건의 구간별 타임라인 | EC2 줄의 `재시도` 칸과 `결과` 칸을 봅니다 |

③ 확인 ✅ — `trace-detail.sh` 예시

```
+시작ms   구간                        출처                      걸린ms 재시도 결과      주석 · 오류
0         d2-user07-api/lab           AWS::ApiGateway::Stage       312      -  ok
4         d2-user07-api-app           AWS::Lambda                  298      -  ok
15        d2-user07-api-app           AWS::Lambda::Function        151      -  ok
16        describe_running            subsegment                   143      -  ok        user_id=user07 max_attempts=5 retry_mode=legacy outcome=ok retry_attempts=0 elapsed_ms=143
17        EC2                         aws                          141      0  ok
```

**콘솔에서도 봅니다:** CloudWatch › X-Ray traces › **Trace map** — `Client → d2-<ME>-api/lab → d2-<ME>-api-app → EC2` 네 개의 노드가 이어져 보이면 됩니다. 노드를 누르면 평균 지연 · 요청 수 · 오류 비율이 나옵니다.

> ◎ 품질팀의 눈
> 실습②에서는 ALB의 p95(바깥에서 잰 숫자)로 판정했습니다. 트레이스는 **같은 요청의 안쪽**을 보여 줍니다. “느렸다”가 아니라 “EC2 API 호출에서 재시도 4번, 9.8초를 썼다”라고 말할 수 있게 됩니다.

□ 완료 □ 막힘

---

## C. 중지 조건 경보 (3분)

### C-1. API Gateway 5xx 경보

① 입력

```bash
aws cloudwatch put-metric-alarm \
  --alarm-name d2-$ME-api-stop-5xx \
  --namespace AWS/ApiGateway \
  --metric-name 5XXError \
  --dimensions Name=ApiName,Value=$API_NAME \
  --statistic Sum --period 60 \
  --evaluation-periods 1 --threshold 30 \
  --comparison-operator GreaterThanOrEqualToThreshold \
  --treat-missing-data notBreaching
```

② 옵션 풀이

| 옵션 · 부분 | 뜻 | 왜 이 값인가 |
|---|---|---|
| `AWS/ApiGateway` · `5XXError` | API Gateway가 고객에게 돌려준 5xx 수 | 고객이 실제로 받은 실패입니다 |
| `Name=ApiName,Value=$API_NAME` | 내 API만 | |
| `--threshold 30` (1분 합계) | 분당 30건 이상이면 FIS 실험을 멈춤 | 실습 스크립트는 분당 최대 10~20건을 보냅니다. **계획보다 피해가 커지면** 멈추는 안전장치입니다 |
| `notBreaching` | 데이터 없음 = 오류 없음 | |

③ 확인 ✅

```bash
aws cloudwatch describe-alarms --alarm-names d2-$ME-api-stop-5xx --query "MetricAlarms[0].StateValue" --output text
```

`OK` 또는 `INSUFFICIENT_DATA`면 됩니다(곧 OK).

> ⓘ 원본 워크숍은 중지 조건 없이 템플릿을 만듭니다. 오늘은 실습③처럼 **중지 조건을 항상 둡니다**.

□ 완료 □ 막힘

---

## D. 실험3 — API 스로틀링 (17분)

**가설:** “EC2 `DescribeInstances` 호출의 75%가 스로틀링되어도 SDK의 자동 재시도 덕분에 모든 고객 요청이 성공하고, 각 요청은 API Gateway 한도(29초) 안에 끝날 것이다.”

### D-1. 실험 템플릿 직접 작성 (콘솔)

콘솔: AWS FIS › 실험 템플릿 › 실험 템플릿 생성 · 대상 계정 ‘이 AWS 계정’

| 화면 위치 | 항목 | 입력값 | 이유 |
|---|---|---|---|
| 세부 정보 | 설명 | `d2-<ME> 실험3 - EC2 API 스로틀링 75% (DescribeInstances)` | 정리 스크립트가 `d2-<ME>` 로 찾습니다 |
| 세부 정보 | 이름 (Name 태그) | `d2-<ME>-exp3-api-throttle` | |
| 작업 › 작업 추가 | 이름 | `APIThrottle` | |
| 작업 | 작업 유형 | **FIS › aws:fis:inject-api-throttle-error** | 대상 역할의 API 호출에 스로틀링 오류를 돌려줍니다 |
| 작업 | 대상 | `Roles-Target-1` (자동 생성) | |
| 작업 파라미터 | duration | **3분** | |
| 작업 파라미터 | operations | **DescribeInstances** | 이 작업만. 쉼표로 여러 개를 줄 수 있습니다 |
| 작업 파라미터 | percentage | **75** | 호출 4번 중 3번 꼴로 스로틀링 |
| 작업 파라미터 | service | **ec2** | 현재 API 장애 주입은 EC2 · Kinesis Data Streams 작업을 지원합니다 |
| 대상 › 편집 | 리소스 유형 | **aws:iam:role** | 서버가 아니라 **역할**이 대상입니다 |
| 대상 | 대상 지정 방법 | 리소스 ID | |
| 대상 | 리소스 ID | **d2-<ME>-api-lambda-role** | 이 역할로 부르는 API만 영향을 받습니다 = 폭발 반경 |
| 대상 | 선택 모드 | 모두 (ALL) | |
| 서비스 액세스 | IAM 역할 | 기존 역할 › **d2-<ME>-fis-api-role** | |
| 중지 조건 | CloudWatch 경보 | **d2-<ME>-api-stop-5xx** | |
| 로그 | CloudWatch Logs로 보내기 | 체크 › 로그 그룹 **/d2/<ME>/fis-api-experiments** | 실험의 시작 · 대상 · 종료 기록 |
| 태그 | Owner | `<ME>` | 목록에서 내 템플릿만 거릅니다 |

✅ 템플릿 ID(EXT…)가 보이면 됩니다. □ 완료

> ⓘ 콘솔 작성이 막히면: `bash ~/day2/정답/lab3_api/create-api-template.sh 3` (JSON `exp3-api-throttle.json` 을 먼저 읽어 봅니다)

### D-2. 템플릿 ID 저장 · 설정 다시 읽기

① 입력

```bash
aws fis list-experiment-templates \
  --query "experimentTemplates[?tags.Owner=='$ME'].[id,description]" --output table
export TPL3=EXT1a2b3c4d5e6f7
aws fis get-experiment-template --id $TPL3 \
  --query "experimentTemplate.{targets:targets,actions:actions,stop:stopConditions,log:logConfiguration}"
```

③ 확인 ✅ — `resourceType: aws:iam:role`, `resourceArns` 가 **내 Lambda 역할**, `parameters` 의 service `ec2` · operations `DescribeInstances` · percentage `75`, `stop` 에 내 경보, `log` 에 내 로그 그룹이 보이면 됩니다.

### D-3. 실험 시작 (run1)

① 입력

```bash
export EXP3=$(aws fis start-experiment --experiment-template-id $TPL3 \
  --tags Owner=$ME,Name=api-throttle-run1 --query "experiment.id" --output text)
echo $EXP3 ; date -u +%H:%M:%S
aws fis get-experiment --id $EXP3 --query "experiment.state.status" --output text
```

✅ `running` 이 되면 **30초를 기다린 뒤** 다음 단계로 갑니다(주입이 실제로 걸리기까지 시간이 걸립니다).

### D-4. 고객 요청 보내기 — 30회

① 입력

```bash
bash run-api-throttle.sh 30
```

③ 확인 ✅ (예시)

```
#    시각     코드  총(ms)   EC2(ms)  재시도  결과 · 트레이스 ID
1    05:12:48 200   1450     1290     2       OK 3대 1-6730b0c1-...
2    05:12:50 200   320      150      0       OK 3대 1-6730b0c3-...
3    05:12:51 503   6020     5880     5       RequestLimitExceeded 1-6730b0c4-...
...
──
성공 24 · 실패 6 · 최대 재시도 5 · 평균 2380ms · 최대 6020ms
```

✅ `재시도` 칸에 0이 아닌 값이 보이고, 실패(`503`)가 몇 건 섞여 있으면 정상입니다. 오류 코드 이름(`RequestLimitExceeded` · `ThrottlingException` 등)은 예시와 다를 수 있습니다. 결과를 기록지 run1 칸에 적습니다.

### D-5. X-Ray — 재시도가 요청 안에서 어떻게 보이나

① 입력 (마지막 요청 후 30초 뒤)

```bash
bash xray-traces.sh 10
bash trace-detail.sh            # 가장 느린 1건
aws logs tail /d2/$ME/fis-api-experiments --since 15m --format short | head -n 20
```

③ 확인 ✅ — `trace-detail.sh` 예시

```
+시작ms   구간                        출처                      걸린ms 재시도 결과      주석 · 오류
0         d2-user07-api/lab           AWS::ApiGateway::Stage      6020      -  FAULT
16        describe_running            subsegment                  5880      -  FAULT     ... outcome=error error_code=RequestLimitExceeded retry_attempts=5
17        EC2                         aws                         5878      5  THROTTLE  ⚠ Request limit exceeded.
```

| 볼 곳 | 품질 관점의 의미 |
|---|---|
| ② 재시도가 있었던 요청 수 | 고객 응답은 200이었어도 **안에서는 재시도**가 있었던 요청 = 숨은 지연 |
| EC2 줄의 `걸린ms` | 재시도 대기(백오프)가 모두 이 구간에 들어 있습니다 |
| ④ 트레이스 맵의 EC2 노드 스로틀 수 | FIS가 주입한 스로틀링이 EC2 노드에 표시됩니다 |
| FIS 실험 로그 | 실험 시작 · 대상 역할 · 작업 시작/종료 시각 = 트레이스와 맞춰 볼 시간축 |

**콘솔:** CloudWatch › X-Ray traces › Traces › 필터 `service("d2-<ME>-api-app") AND annotation.retry_attempts > 0` → 트레이스 하나를 열어 타임라인에서 EC2 구간을 봅니다.

### D-6. 개선 — 재시도 늘리기 (워크숍의 코드 수정을 환경 변수로)

① 입력

```bash
aws lambda update-function-configuration --function-name $APP_FN \
  --environment "Variables={USER_ID=$ME,MAX_ATTEMPTS=10,RETRY_MODE=standard}" \
  --query "Environment.Variables"
aws lambda wait function-updated --function-name $APP_FN
curl -s $API_URL/describe | jq '{MaxAttempts, RetryMode}'
```

② 옵션 풀이

| 부분 | 뜻 | 왜 |
|---|---|---|
| `MAX_ATTEMPTS=10` · `RETRY_MODE=standard` | 코드의 `Config(retries={'max_attempts':10,'mode':'standard'})` 값 | 워크숍은 Lambda 콘솔에서 코드를 고칩니다. 여기서는 코드가 환경 변수를 읽으므로 설정만 바꿉니다 |
| `Variables={…}` 전체 | 환경 변수는 **통째로 바뀝니다** | `USER_ID` 를 빠뜨리면 함수가 실패합니다 |
| `wait function-updated` | 설정 반영을 기다립니다 | |

✅ `{"MaxAttempts": 10, "RetryMode": "standard"}` 가 나오면 됩니다.

### D-7. 같은 실험 다시 (run2)

① 입력

```bash
export EXP3B=$(aws fis start-experiment --experiment-template-id $TPL3 \
  --tags Owner=$ME,Name=api-throttle-run2 --query "experiment.id" --output text)
sleep 30
bash run-api-throttle.sh 30
bash xray-traces.sh 5
```

✅ 재시도 6 이상이 보이나요? 실패는 줄었나요? **최대 응답 시간**은 어떻게 됐나요? `502`(Lambda 28초 타임아웃) 또는 29초 근처 응답이 보이면 X-Ray에서 그 트레이스를 열어 봅니다.

| 비교 | run1 (5회 · legacy) | run2 (10회 · standard) | 해석 |
|---|---|---|---|
| 성공 / 실패 | / | / | |
| 최대 재시도 | | | |
| 평균 · 최대 응답(ms) | / | / | |
| 29초 근처 · 502 건수 | | | |
| X-Ray 스로틀 수 (EC2 노드) | | | |

> ◎ 품질팀의 눈
> 재시도를 늘리면 **실패는 줄지만 느려집니다**. 동기 API는 Lambda 타임아웃(28초)과 API Gateway 한도(29초)에 막혀 결국 실패로 바뀝니다. 재시도 횟수는 ‘많을수록 좋은 값’이 아니라 **응답 시간 예산과 맞바꾸는 값**입니다. 배치 작업이면 늘리고, 고객이 기다리는 API면 줄이고 빨리 실패하게 합니다.

### D-8. 설정 되돌리기

```bash
aws lambda update-function-configuration --function-name $APP_FN \
  --environment "Variables={USER_ID=$ME,MAX_ATTEMPTS=5,RETRY_MODE=legacy}" --query "Environment.Variables"
aws lambda wait function-updated --function-name $APP_FN
```

□ 완료 □ 막힘

---

## E. 실험4 — API 사용 불가: 동기 vs 비동기 (12분)

**가설:** “EC2 API가 3분 동안 완전히 사용 불가여도, 종료 요청은 **유실되지 않고** 장애가 끝난 뒤 처리될 것이다.”

### E-1. 실험 템플릿 (콘솔) — D-1과 다른 칸만

| 항목 | 입력값 |
|---|---|
| 설명 · 이름 | `d2-<ME> 실험4 - EC2 API 사용 불가 100% (DescribeInstances, TerminateInstances)` · `d2-<ME>-exp4-api-unavailable` |
| 작업 이름 · 유형 | `APIError` · **aws:fis:inject-api-unavailable-error** |
| operations | **DescribeInstances,TerminateInstances** (쉼표, 띄어쓰기 없이) |
| percentage | **100** |
| service · duration | `ec2` · 3분 |

대상 · 역할 · 중지 조건 · 로그 · 태그는 D-1과 같습니다. 따라잡기: `bash ~/day2/정답/lab3_api/create-api-template.sh 4`

```bash
export TPL4=EXT…        # list-experiment-templates 로 확인한 내 ID
```

### E-2. 실험 전 확인 — 아직 종료하지 않습니다

① 입력

```bash
bash run-api-unavailable.sh
```

질문에 **NO**(그냥 Enter)로 답합니다. 정상 응답과 **희생 인스턴스 ID**를 기록합니다.

> ⚠ 실험 전에 `POST /terminate` 를 부르면 희생 인스턴스가 바로 종료됩니다. 그랬다면 ASG가 1~2분 안에 새로 만드니 기다렸다가 진행합니다.

### E-3. 실험 시작 → 동기 호출 (실패를 확인)

① 입력

```bash
export EXP4=$(aws fis start-experiment --experiment-template-id $TPL4 \
  --tags Owner=$ME,Name=api-unavailable-run1 --query "experiment.id" --output text)
echo $EXP4 ; date -u +%H:%M:%S
sleep 30
bash run-api-unavailable.sh        # 이번에는 yes
```

③ 확인 ✅ (예시)

```
05:31:10  {"Error": "ServiceUnavailable", "Message": "An error occurred (ServiceUnavailable) when calling the DescribeInstances operation ...", "RetryAttempts": 4, ...}  [HTTP 503 · 3.9s]
...
== 희생 인스턴스 (실험 중에는 그대로 running 이어야 합니다)
i-07c3d2e1f0a9b8c7d  running  2026-11-10T04:40:02+00:00
```

✅ 모든 호출이 503이고 인스턴스는 그대로입니다. **고객의 종료 요청은 실패했고, 다시 해 달라는 책임이 고객에게 넘어갔습니다.**

### E-4. 비동기 호출 — 큐에 맡기기

① 입력 (실험이 아직 running 인지 `aws fis get-experiment --id $EXP4 --query experiment.state.status --output text` 로 확인)

```bash
bash run-api-unavailable2.sh
bash run-api-unavailable2.sh watch      # 실험이 끝나고 인스턴스가 shutting-down 이 될 때까지. Ctrl+C로 끝
```

③ 확인 ✅ (예시)

```
== POST /async (실험 중이어도 즉시 응답해야 합니다)
{"queued": true, "messageId": "5f1c..."}  [HTTP 200 · 0.08s]
05:32:02  큐: 대기 0 · 처리 중(재시도 대기) 1  |  희생 인스턴스: i-07c3d2e1f0a9b8c7d running
05:32:22  큐: 대기 0 · 처리 중(재시도 대기) 1  |  희생 인스턴스: i-07c3d2e1f0a9b8c7d running
...
05:34:42  큐: 대기 0 · 처리 중(재시도 대기) 0  |  희생 인스턴스: i-07c3d2e1f0a9b8c7d shutting-down
```

| 관찰 | 의미 |
|---|---|
| `HTTP 200 · 0.08s` | 응답은 SQS `SendMessage` 가 만든 것입니다. EC2 API 장애와 무관하게 **즉시 접수** |
| 처리 중 1이 계속 | Lambda가 꺼내 시도 → 실패 → 30초 뒤 다시 보임 → 재시도 |
| 실험 종료(3분) 뒤 shutting-down | 장애가 끝나자 **요청이 결국 처리됨**. 이후 ASG가 새 희생 인스턴스를 만듭니다 |

### E-5. 근거 남기기 — 로그 · X-Ray · DLQ

① 입력

```bash
aws logs tail /aws/lambda/$APP_FN --since 10m --format short | grep -E '"async"|Task timed out|ServiceUnavailable' | tail -n 10
bash xray-traces.sh 10
aws sqs get-queue-attributes --attribute-names ApproximateNumberOfMessages \
  --queue-url $(aws sqs get-queue-url --queue-name d2-$ME-api-dlq --query QueueUrl --output text) \
  --query "Attributes.ApproximateNumberOfMessages" --output text
```

③ 확인 ✅ — 로그의 마지막 `"async": true` 줄에 `"receive_count": "6"` 처럼 **몇 번째 시도에 성공했는지**와 `"Terminated": "i-…"` 가 있고, DLQ는 `0` 이면 됩니다. X-Ray ① 요약에서 실험 구간의 fault 수와 그 뒤의 정상 트레이스를 봅니다.

> ◎ 품질팀의 눈
> 동기 경로는 장애 동안 **고객 요청 100% 실패**, 비동기 경로는 **접수 100% 성공 · 처리 지연 약 3분 · 유실 0**입니다. 판정 기준이 “성공률”에서 “유실 0 · 처리 완료 시간”으로 바뀐다는 점이 핵심입니다. 비동기는 공짜가 아닙니다 — 중복 처리(멱등성), DLQ 감시, 처리 지연을 고객에게 어떻게 알릴지를 함께 요구해야 합니다.

□ 완료 □ 막힘

---

## F. 판정 (3분)

| 가설 항목 | 기준 | 측정값 | 판정 |
|---|---|---|---|
| 실험3 run1: 스로틀링 75%에서 고객 요청 성공률 | 100% | % | |
| 실험3 run1: 최대 응답 시간 | < 29초 | ms | |
| 실험3 run2 (재시도 10): 성공률 · 최대 응답 | 100% · < 29초 | % · ms | |
| X-Ray: 재시도가 있었던 요청 비율 (②건 ÷ ①전체) | (기록) | % | |
| 실험4 동기: 종료 요청 성공 | (예상: 0%) | % | |
| 실험4 비동기: 접수 · 유실 · 처리 완료 시간 | 접수 100% · 유실 0 · 실험 종료 후 2분 안 | / / 분 | |
| 중지 조건 발동 | 발동 안 함 | | |
| **종합** | | | PASS / 조건부 / FAIL |

**판정 문장 틀 — 기준 · 측정 · 판정 · 다음 행동 · 되물을 질문**

> “EC2 API 스로틀링 75% · 3분 조건에서 bill-ops API 성공률 ___%, 최대 응답 ___ms(X-Ray: 요청 ___%가 내부 재시도, EC2 구간 최대 ___ms) → [판정].
> 재시도를 10회로 늘리면 성공률 ___% · 최대 ___ms로, 실패가 타임아웃으로 바뀌었다.
> API 완전 사용 불가 3분 동안 동기 종료 요청은 ___% 실패, 비동기 경로는 유실 ___건 · 처리 지연 ___분.
> 다음 행동: ________ (예: 변경 작업은 큐로 비동기화, 고객 API의 재시도 예산을 응답 시간 SLO에 맞춤, DLQ 경보 추가)
> 되물을 질문: “AWS API가 3분 동안 안 될 때, 이 기능은 고객에게 무엇을 보여 주나요?””

---

## G. 정리

```bash
aws fis list-experiments --query "experiments[?tags.Owner=='$ME'].[id,state.status,tags.Name]" --output table
bash ~/day2/setup/cleanup_v2.sh $ME --dry-run
bash ~/day2/setup/cleanup_v2.sh $ME
```

`cleanup_v2.sh` 는 기존 `cleanup.sh` 의 모든 단계에 **API 실험 스택 `d2-<ME>-api` 와 X-Ray SDK 레이어 삭제**를 더한 버전입니다. 실험 템플릿(설명 `d2-<ME>`)과 경보(`d2-<ME>-api-stop-5xx`)도 기존 단계에서 함께 지워집니다.

---

## 부록. 막혔을 때

| 증상 | 원인 · 조치 |
|---|---|
| `setup_api_v2.sh` ✗ d2-shared 없음 | 네트워크 스택이 먼저 필요합니다. `bash ~/day2/setup/setup.sh $ME` |
| `△ pip 설치 실패 — SDK 없이 배포` | 실습은 됩니다. 트레이스에 EC2 · describe_running 구간이 없고 API Gateway · Lambda 구간만 보입니다. `annotation.*` 필터도 비어 있습니다 |
| curl 결과가 `{"message":"Missing Authentication Token"}` | 경로 오타입니다. `/describe`(GET), `/terminate`(POST), `/async`(POST) 만 있습니다. `API_URL` 끝이 `/lab` 인지 확인 |
| `/async` 가 `415 Unsupported Media Type` | `Content-Type: application/json` 헤더가 빠졌습니다. 스크립트를 쓰면 자동으로 붙습니다 |
| 실험을 시작했는데 재시도가 0 | 주입이 걸리기까지 약 30초가 걸립니다. 기다린 뒤 다시 보냅니다. 75%라 운이 좋으면 몇 건은 0입니다 |
| FIS 실험 failed (권한 · 대상) | 템플릿의 대상이 **d2-<ME>-api-lambda-role**(웹 서비스의 d2-<ME>-fis-role 아님), 실행 역할이 **d2-<ME>-fis-api-role** 인지 `get-experiment-template` 으로 확인 |
| FIS 실험이 바로 stopped | 중지 경보가 ALARM입니다. 1~2분 뒤 OK가 되면 다시 시작. 스크립트를 동시에 여러 개 돌리지 않습니다 |
| `xray-traces.sh` 가 모두 0 | 요청 후 30초 뒤 다시 실행. `APP_FN` 값 확인. 시간 범위를 늘립니다: `bash xray-traces.sh 30` |
| X-Ray 트레이스 맵에 EC2 노드가 없다 | SDK 레이어가 없는 상태입니다(위 pip 항목). `aws lambda get-function-configuration --function-name $APP_FN --query Layers` |
| `update-function-configuration` 뒤 함수 오류 `KeyError: 'USER_ID'` | 환경 변수는 통째로 바뀝니다. `USER_ID=$ME` 를 함께 넣어 다시 실행 |
| 희생 인스턴스가 없다 | 이미 종료됐습니다. ASG가 1~2분 안에 새로 만듭니다: `aws autoscaling describe-auto-scaling-groups --auto-scaling-group-names d2-$ME-api-victim-asg --query "AutoScalingGroups[0].Instances[].[InstanceId,LifecycleState]" --output table` |
| 실습③ 템플릿이 희생 인스턴스를 고를까? | 고르지 않습니다. 희생 인스턴스에는 `Owner` 태그가 없고(`ApiOwner` 만 있음), 웹 FIS 역할도 `Owner=<ME>` 인스턴스만 종료할 수 있습니다 |

## 따라잡기 파일 (`~/day2/정답/lab3_api/`)

| 파일 | 쓰는 곳 |
|---|---|
| `exp3-api-throttle.json` · `exp4-api-unavailable.json` | D-1 · E-1 실험 템플릿 (CLI 생성용) |
| `create-api-template.sh` | `bash create-api-template.sh 3` 또는 `4` |
| `lab3_api_commands.sh` | 이 실습의 모든 명령 모음 |

## 이 폴더의 스크립트 (`~/day2/lab3_api/`)

| 파일 | 워크숍 대응 | 하는 일 |
|---|---|---|
| `run-api-throttle.sh [N] [간격]` | run-api-throttle.sh | GET /describe N회 · 코드 · 시간 · 재시도 · 트레이스 ID 표 |
| `run-api-unavailable.sh [N]` | run-api-unavailable.sh | NO: 정상 확인만 / yes: POST /terminate 를 10초 간격 N회 |
| `run-api-unavailable2.sh [watch]` | run-api-unavailable2.sh | POST /async (SQS) · 큐 · 희생 인스턴스 상태 |
| `xray-traces.sh [분]` | (추가) | 트레이스 요약 · 재시도 트레이스 · 느린 요청 · 트레이스 맵 노드 통계 |
| `trace-detail.sh [트레이스ID]` | (추가) | 트레이스 1건을 구간별 타임라인으로 |
