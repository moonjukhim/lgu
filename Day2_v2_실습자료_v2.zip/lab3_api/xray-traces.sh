#!/bin/bash
# 실습⑤ (API 실험) — X-Ray 트레이스로 "고객 요청 안에서 무슨 일이 있었나"를 봅니다.
#   bash xray-traces.sh        최근 10분
#   bash xray-traces.sh 20     최근 20분
# 트레이스는 요청 후 30초쯤 지나야 조회됩니다. 시각은 UTC입니다.
# 필요한 변수: APP_FN, ME
[ -f ~/day2.env ] && source ~/day2.env
: "${APP_FN:?APP_FN 이 비어 있습니다. source ~/day2.env}"
MIN=${1:-10}
S=$(( $(date +%s) - MIN*60 )); E=$(date +%s)
F="service(\"$APP_FN\")"

echo "== ① 요약 (최근 ${MIN}분, 서비스 $APP_FN)"
aws xray get-trace-summaries --start-time $S --end-time $E --filter-expression "$F" \
  --query "{total:length(TraceSummaries), ok:length(TraceSummaries[?!HasError && !HasFault && !HasThrottle]), error_4xx:length(TraceSummaries[?HasError]), fault_5xx:length(TraceSummaries[?HasFault]), throttle_429:length(TraceSummaries[?HasThrottle])}" \
  --output table

echo "== ② SDK가 재시도한 요청 (filter: annotation.retry_attempts > 0)"
aws xray get-trace-summaries --start-time $S --end-time $E \
  --filter-expression "$F AND annotation.retry_attempts > 0" \
  --query "sort_by(TraceSummaries,&ResponseTime)[].[Id, ResponseTime, Annotations.retry_attempts[0].AnnotationValue.NumberValue, Annotations.max_attempts[0].AnnotationValue.NumberValue, Annotations.outcome[0].AnnotationValue.StringValue]" \
  --output table

echo "== ③ 가장 느린 요청 5건 (응답 시간 초)"
aws xray get-trace-summaries --start-time $S --end-time $E --filter-expression "$F" \
  --query "sort_by(TraceSummaries,&ResponseTime)[-5:].[Id, ResponseTime, HasFault, HasThrottle]" --output table

echo "== ④ 트레이스 맵 노드별 통계 (내 API · Lambda · EC2)"
printf '%-34s %-22s %6s %6s %6s %6s %9s\n' "노드" "유형" "전체" "정상" "스로틀" "5xx" "평균(ms)"
aws xray get-service-graph --start-time $S --end-time $E \
  --query "Services[?contains(Name,'$ME') || Type=='AWS::EC2' || Name=='EC2'].[Name, Type, SummaryStatistics.TotalCount, SummaryStatistics.OkCount, SummaryStatistics.ErrorStatistics.ThrottleCount, SummaryStatistics.FaultStatistics.TotalCount, SummaryStatistics.TotalResponseTime]" \
  --output text | awk -F'\t' '{avg = ($3>0) ? $7/$3*1000 : 0; printf "%-34s %-22s %6s %6s %6s %6s %9d\n", $1, $2, $3, $4, $5, $6, avg}'

echo
echo "→ 한 건을 펼쳐 보려면: bash trace-detail.sh <트레이스ID>   (ID 없이 실행하면 가장 느린 1건)"
echo "→ 콘솔: CloudWatch › X-Ray traces › Trace map / Traces (필터에 위 filter 식을 그대로 붙여 넣습니다)"
