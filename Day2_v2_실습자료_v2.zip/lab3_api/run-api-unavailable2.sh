#!/bin/bash
# 실습⑤ (API 실험) — 비동기 변경 호출: POST /async → API Gateway가 SQS에 바로 넣고 즉시 응답
#   Lambda가 큐에서 꺼내 TerminateInstances 를 시도하고, 실패하면 메시지가 30초 뒤 다시 보여 재시도됩니다.
#   bash run-api-unavailable2.sh          요청 1건 + 큐 상태 확인
#   bash run-api-unavailable2.sh watch    큐 상태 · 희생 인스턴스를 20초마다 (Ctrl+C로 끝)
# 필요한 변수: API_URL, ME, QUEUE
[ -f ~/day2.env ] && source ~/day2.env
: "${API_URL:?API_URL 이 비어 있습니다. source ~/day2.env}"
: "${QUEUE:?QUEUE 가 비어 있습니다. 가이드 A-2 참고}"
QURL=$(aws sqs get-queue-url --queue-name "$QUEUE" --query QueueUrl --output text)

status() {
  printf '%s  큐: ' "$(date -u +%H:%M:%S)"
  aws sqs get-queue-attributes --queue-url "$QURL" \
    --attribute-names ApproximateNumberOfMessages ApproximateNumberOfMessagesNotVisible \
    --query "Attributes.[ApproximateNumberOfMessages,ApproximateNumberOfMessagesNotVisible]" --output text \
    | awk '{printf "대기 %s · 처리 중(재시도 대기) %s", $1, $2}'
  printf '  |  희생 인스턴스: '
  aws ec2 describe-instances --filters Name=tag:Role,Values=api-victim Name=tag:ApiOwner,Values="$ME" \
    Name=instance-state-name,Values=pending,running,shutting-down \
    --query "Reservations[].Instances[].[InstanceId,State.Name]" --output text | tr '\n\t' '  '
  echo
}

if [ "${1:-}" = "watch" ]; then
  while true; do status; sleep 20; done
fi

echo "== POST /async (실험 중이어도 즉시 응답해야 합니다)"
curl -s -X POST -H 'Content-Type: application/json' \
  -d "{\"action\":\"terminate-victim\",\"requested_by\":\"$ME\",\"requested_at\":\"$(date -u +%FT%TZ)\"}" \
  -w '  [HTTP %{http_code} · %{time_total}s]\n' "$API_URL/async"
status
echo "→ 계속 보려면: bash run-api-unavailable2.sh watch"
