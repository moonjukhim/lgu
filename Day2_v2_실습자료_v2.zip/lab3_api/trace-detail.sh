#!/bin/bash
# 실습⑤ (API 실험) — 트레이스 1건을 구간(세그먼트 · 서브세그먼트)별 타임라인으로 펼칩니다.
#   bash trace-detail.sh 1-6730a1b2-0123456789abcdef01234567
#   bash trace-detail.sh                 최근 10분 중 가장 느린 1건
# 보는 법: API Gateway → Lambda → describe_running(내 코드) → EC2 DescribeInstances(SDK) 순서.
#          EC2 줄의 '재시도' 칸이 SDK가 다시 시도한 횟수, '결과'가 THROTTLE/FAULT면 FIS가 주입한 오류입니다.
[ -f ~/day2.env ] && source ~/day2.env
ID=${1:-}
if [ -z "$ID" ]; then
  : "${APP_FN:?APP_FN 이 비어 있습니다. source ~/day2.env}"
  ID=$(aws xray get-trace-summaries --start-time $(( $(date +%s) - 600 )) --end-time "$(date +%s)" \
         --filter-expression "service(\"$APP_FN\")" \
         --query "sort_by(TraceSummaries,&ResponseTime)[-1].Id" --output text)
  [ -z "$ID" ] || [ "$ID" = "None" ] && { echo "최근 10분 트레이스가 없습니다. 요청 후 30초 뒤 다시 실행하세요."; exit 1; }
fi
echo "트레이스 $ID"
printf '%-9s %-26s %-24s %8s %6s %-9s %s\n' "+시작ms" "구간" "출처" "걸린ms" "재시도" "결과" "주석 · 오류"
aws xray batch-get-traces --trace-ids "$ID" --output json | jq -r '
  [.Traces[0].Segments[].Document | fromjson | recurse(.subsegments[]?)] as $all
  | ($all | map(.start_time) | min) as $t0
  | $all | sort_by(.start_time)[]
  | [ (((.start_time - $t0) * 1000) | floor),
      .name,
      (.origin // (if .namespace then .namespace else "subsegment" end)),
      (if .end_time then (((.end_time - .start_time) * 1000) | floor) else "진행중" end),
      (.aws.retries // "-"),
      (if .throttle then "THROTTLE" elif .fault then "FAULT" elif .error then "ERROR" else "ok" end),
      ( ((.annotations // {}) | to_entries | map("\(.key)=\(.value)") | join(" "))
        + (if ((.cause | type) == "object") and ((.cause.exceptions // []) | length > 0)
           then "  ⚠ " + ((.cause.exceptions[0].message // .cause.exceptions[0].type // "") | tostring | .[0:80])
           else "" end) ) ]
  | @tsv' | awk -F'\t' '{printf "%-9s %-26s %-24s %8s %6s %-9s %s\n", $1, $2, $3, $4, $5, $6, $7}'
