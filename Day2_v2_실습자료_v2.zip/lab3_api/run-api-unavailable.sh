#!/bin/bash
# 실습⑤ (API 실험) — 동기 변경 호출: POST /terminate (희생 인스턴스 종료)
#   실험 전 (NO)  : GET /describe 로 정상 상태와 희생 인스턴스만 확인합니다. 종료하지 않습니다.
#   실험 중 (yes) : POST /terminate 를 10초 간격으로 N번 호출합니다 (기본 6번 = 1분).
# 필요한 변수: API_URL, ME
[ -f ~/day2.env ] && source ~/day2.env
: "${API_URL:?API_URL 이 비어 있습니다. source ~/day2.env}"
N=${1:-6}

victim() {
  aws ec2 describe-instances --filters Name=tag:Role,Values=api-victim Name=tag:ApiOwner,Values="$ME" \
    Name=instance-state-name,Values=pending,running,shutting-down \
    --query "Reservations[].Instances[].[InstanceId,State.Name,LaunchTime]" --output text
}

read -r -p "FIS 실험(실험4 · API 사용 불가)이 지금 실행 중입니까? (yes/NO) " A
if [ "$A" != "yes" ]; then
  echo "== 정상 상태 확인 (종료 호출은 하지 않습니다)"
  curl -s "$API_URL/describe"
  echo "== 희생 인스턴스 (ID · 상태 · 시작 시각)"; victim
  exit 0
fi

echo "== 실험 중: POST /terminate 를 10초 간격으로 ${N}번"
for i in $(seq 1 "$N"); do
  printf '%s  ' "$(date -u +%H:%M:%S)"
  curl -s -m 35 -X POST -w '  [HTTP %{http_code} · %{time_total}s]\n' "$API_URL/terminate" | tr -d '\n'; echo
  sleep 10
done
echo "== 희생 인스턴스 (실험 중에는 그대로 running 이어야 합니다)"; victim
