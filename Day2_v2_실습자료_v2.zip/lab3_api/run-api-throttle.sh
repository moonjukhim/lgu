#!/bin/bash
# 실습⑤ (API 실험) — GET /describe 를 N번 호출하고 응답 코드 · 시간 · 재시도 횟수 · 트레이스 ID를 표로 봅니다.
#   bash run-api-throttle.sh          20회 (기본)
#   bash run-api-throttle.sh 40 0.5   40회, 호출 간격 0.5초
# 필요한 변수: API_URL  (source ~/day2.env)
[ -f ~/day2.env ] && source ~/day2.env
N=${1:-20}; GAP=${2:-0.2}
: "${API_URL:?API_URL 이 비어 있습니다. 가이드 A-2에서 변수를 만들고 source ~/day2.env 를 실행하세요}"

printf '%-4s %-8s %-5s %-8s %-8s %-7s %s\n' "#" "시각" "코드" "총(ms)" "EC2(ms)" "재시도" "결과 · 트레이스 ID"
ok=0; err=0; maxr=0; tsum=0; tmax=0
for i in $(seq 1 "$N"); do
  R=$(curl -s -m 35 -w '\n%{http_code} %{time_total}' "$API_URL/describe")
  BODY=$(echo "$R" | head -n -1); read -r CODE SEC <<<"$(echo "$R" | tail -n 1)"
  MS=$(awk -v s="$SEC" 'BEGIN{printf "%d", s*1000}')
  RET=$(echo "$BODY" | jq -r '.RetryAttempts // "-"' 2>/dev/null || echo "-")
  EMS=$(echo "$BODY" | jq -r '.ElapsedMs // "-"' 2>/dev/null || echo "-")
  TID=$(echo "$BODY" | jq -r '.TraceId // ""' 2>/dev/null)
  if [ "$CODE" = "200" ]; then
    ok=$((ok+1)); RES="OK $(echo "$BODY" | jq -r '.InstanceIds | length' 2>/dev/null)대"
  else
    err=$((err+1)); RES="$(echo "$BODY" | jq -r '.Error // .message // "응답 없음/타임아웃"' 2>/dev/null)"
  fi
  [[ "$RET" =~ ^[0-9]+$ ]] && (( RET > maxr )) && maxr=$RET
  tsum=$((tsum+MS)); (( MS > tmax )) && tmax=$MS
  printf '%-4s %-8s %-5s %-8s %-8s %-7s %s %s\n' "$i" "$(date -u +%H:%M:%S)" "$CODE" "$MS" "$EMS" "$RET" "$RES" "$TID"
  sleep "$GAP"
done
echo "──"
echo "성공 $ok · 실패 $err · 최대 재시도 $maxr · 평균 $((tsum/N))ms · 최대 ${tmax}ms   (시각은 UTC)"
