#!/usr/bin/env bash
# Day 2 v2 (추가 실습) — FIS API 장애 주입 + X-Ray 실습 환경을 내 계정에 준비합니다.
#
#   bash ~/day2/setup/setup_api_v2.sh user07           X-Ray SDK 레이어 → 스택 d2-user07-api → 응답 확인
#   bash ~/day2/setup/setup_api_v2.sh user07 --check   사전 점검만
#
# 먼저 setup.sh 로 네트워크 스택 d2-shared 가 있어야 합니다 (실습① 이전에 이미 만들어 둔 것).
# 만드는 것: API Gateway(X-Ray 켬) · Lambda(X-Ray 켬) · SQS · 희생 인스턴스 1대(ASG) · FIS 실행 역할 · 실험 로그 그룹
# 만들지 않는 것: 중지 조건 경보 · FIS 실험 템플릿 (실습 가이드를 보며 직접 입력)
# 여러 번 실행해도 안전합니다.
set -uo pipefail
export AWS_REGION=ap-northeast-2 AWS_DEFAULT_REGION=ap-northeast-2
DIR=$(cd "$(dirname "$0")" && pwd)
ME=${1:-${ME:-}}
MODE=${2:-}
STACK="d2-$ME-api"
LAYER="d2-$ME-xray-sdk"
FAIL=0

ok()   { printf '  ✔ %s\n' "$*"; }
warn() { printf '  △ %s\n' "$*"; }
bad()  { printf '  ✗ %s\n' "$*"; FAIL=1; }

[[ "$ME" =~ ^user[0-9]{2}$ ]] || { echo "사용법: bash ~/day2/setup/setup_api_v2.sh user07"; exit 1; }

echo "═══ 1. 사전 점검 (리전 $AWS_REGION · 참가자 ID $ME)"
ACCT=$(aws sts get-caller-identity --query Account --output text 2>/dev/null) \
  || { echo "  ✗ AWS 자격 증명을 찾지 못했습니다."; exit 1; }
ok "계정 $ACCT"

SH=$(aws cloudformation describe-stacks --stack-name d2-shared --query "Stacks[0].StackStatus" --output text 2>/dev/null || echo NONE)
[[ "$SH" == *COMPLETE && "$SH" != *DELETE* && "$SH" != *ROLLBACK* ]] \
  && ok "네트워크 스택 d2-shared ($SH)" \
  || bad "네트워크 스택 d2-shared 가 없습니다 ($SH). 먼저 bash ~/day2/setup/setup.sh $ME 를 실행하세요."

Q=$(aws service-quotas get-service-quota --service-code ec2 --quota-code L-1216C47A \
      --query "Quota.Value" --output text 2>/dev/null || echo "?")
if [[ "$Q" != "?" ]] && ! awk -v q="$Q" 'BEGIN{exit !(q>=10)}'; then
  warn "vCPU 한도 ${Q%.*}: 웹 ASG 최대 4대(8) + 희생 인스턴스 1대(2) = 10. 웹 ASG가 2대일 때(실습③ 이후) 진행하세요."
fi

aws fis list-actions --query "actions[?id=='aws:fis:inject-api-throttle-error'].id" --output text 2>/dev/null \
  | grep -q inject-api && ok "FIS API 장애 액션 사용 가능 (aws:fis:inject-api-*)" \
  || bad "FIS 액션 aws:fis:inject-api-throttle-error 를 찾지 못했습니다."

command -v pip3 >/dev/null && ok "pip3 있음 (X-Ray SDK 레이어 빌드용)" \
  || warn "pip3 가 없습니다 — X-Ray SDK 없이 배포합니다 (Lambda · API Gateway 구간만 트레이스)."

if [[ "$MODE" == "--check" ]]; then
  echo; (( FAIL )) && echo "✗ 해결할 항목이 있습니다." || echo "✔ 사전 점검 통과."
  exit $FAIL
fi
(( FAIL )) && { echo; echo "✗ 사전 점검에서 문제가 있어 배포하지 않았습니다."; exit 1; }

echo
echo "═══ 2. X-Ray SDK 레이어 $LAYER (약 30초)"
LAYER_ARN=$(aws lambda list-layer-versions --layer-name "$LAYER" \
              --query "LayerVersions[0].LayerVersionArn" --output text 2>/dev/null || echo None)
if [[ -n "$LAYER_ARN" && "$LAYER_ARN" != "None" ]]; then
  ok "이미 있는 레이어를 씁니다: ${LAYER_ARN##*:layer:}"
elif command -v pip3 >/dev/null; then
  B=$(mktemp -d)
  # Lambda python3.12(x86_64)용 휠을 받습니다. botocore 는 Lambda 런타임 것을 쓰도록 넣지 않습니다(--no-deps).
  if pip3 install --quiet --no-deps --target "$B/python" \
       --platform manylinux2014_x86_64 --implementation cp --python-version 3.12 --only-binary=:all: \
       aws-xray-sdk==2.14.0 wrapt==1.16.0 >/tmp/d2-pip.log 2>&1 \
     && (cd "$B" && python3 -m zipfile -c layer.zip python >/dev/null); then
    LAYER_ARN=$(aws lambda publish-layer-version --layer-name "$LAYER" \
                  --description "aws-xray-sdk 2.14.0 for Day2 API lab" \
                  --compatible-runtimes python3.12 --zip-file "fileb://$B/layer.zip" \
                  --query LayerVersionArn --output text 2>/tmp/d2-layer.err) \
      && ok "레이어 게시: ${LAYER_ARN##*:layer:}" \
      || { warn "레이어 게시 실패 — SDK 없이 배포합니다. $(tail -c 200 /tmp/d2-layer.err)"; LAYER_ARN=""; }
  else
    warn "pip 설치 실패 — SDK 없이 배포합니다. $(tail -n 2 /tmp/d2-pip.log)"; LAYER_ARN=""
  fi
  rm -rf "$B"
else
  LAYER_ARN=""
fi

echo
echo "═══ 3. API 실험 스택 $STACK (약 3~4분)"
st=$(aws cloudformation describe-stacks --stack-name "$STACK" --query "Stacks[0].StackStatus" --output text 2>/dev/null || echo NONE)
if [[ "$st" == "ROLLBACK_COMPLETE" || "$st" == "ROLLBACK_FAILED" ]]; then
  warn "$STACK 이 $st 상태입니다. 지우고 다시 만듭니다."
  aws cloudformation delete-stack --stack-name "$STACK"
  aws cloudformation wait stack-delete-complete --stack-name "$STACK"
fi
# 주의: 스택 태그에 Owner 를 넣지 않습니다. 스택 태그는 ASG 인스턴스로 전파되어
#       실습③ FIS 템플릿(Owner=<ME>)이 희생 인스턴스를 고를 수 있게 되기 때문입니다.
if aws cloudformation deploy --stack-name "$STACK" --template-file "$DIR/d2-api-actions_v2.yaml" \
     --no-fail-on-empty-changeset --capabilities CAPABILITY_NAMED_IAM \
     --parameter-overrides UserId="$ME" XRaySdkLayerArn="$LAYER_ARN" \
     --tags Lab=day2 ApiOwner="$ME" >/tmp/d2-api-deploy.log 2>&1; then
  ok "$STACK $(aws cloudformation describe-stacks --stack-name "$STACK" --query "Stacks[0].StackStatus" --output text)"
else
  bad "$STACK 배포 실패"
  tail -n 5 /tmp/d2-api-deploy.log | sed 's/^/      /'
  echo "      실패 원인: aws cloudformation describe-stack-events --stack-name $STACK --max-items 10 \\"
  echo "        --query \"StackEvents[?contains(ResourceStatus,'FAILED')].[LogicalResourceId,ResourceStatusReason]\" --output table"
  exit 1
fi

out() { aws cloudformation describe-stacks --stack-name "$STACK" \
          --query "Stacks[0].Outputs[?OutputKey=='$1'].OutputValue" --output text; }
URL=$(out ApiUrl)

echo
echo "═══ 4. 응답 확인"
for i in $(seq 1 12); do
  R=$(curl -s -m 30 "$URL/describe" || true)
  [[ "$R" == *InstanceIds* ]] && break
  sleep 5
done
if [[ "$R" == *InstanceIds* ]]; then
  ok "GET $URL/describe"
  echo "      $R"
else
  warn "아직 응답이 없습니다. 1분 뒤 curl -s $URL/describe 로 다시 확인하세요."
fi
V=$(aws ec2 describe-instances --filters Name=tag:Role,Values=api-victim Name=tag:ApiOwner,Values="$ME" \
      Name=instance-state-name,Values=pending,running --query "Reservations[].Instances[].InstanceId" --output text)
[[ -n "$V" ]] && ok "희생 인스턴스: $V" || warn "희생 인스턴스가 아직 없습니다 (ASG가 1~2분 안에 만듭니다)."

echo
echo "✔ 준비 완료. 실습 가이드 ~/day2/lab3_api/README.md 의 A-1에서 스택 출력값을 직접 조회해 변수를 만듭니다."
echo "  정리: bash ~/day2/setup/cleanup_v2.sh $ME  (기존 실습 + API 실습을 함께 지웁니다)"
