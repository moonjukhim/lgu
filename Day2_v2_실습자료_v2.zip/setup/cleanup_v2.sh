#!/usr/bin/env bash
# Day 2 v2 — 교육이 끝나면 내 계정의 실습 리소스를 모두 지웁니다 (요금은 내 계정에 나옵니다)
#   bash ~/day2/setup/cleanup_v2.sh user07 --dry-run    지울 목록만 보기
#   bash ~/day2/setup/cleanup_v2.sh user07              확인(yes) 후 삭제 — 스택 삭제는 창을 닫아도 계속됩니다
#
# v2: 추가 실습 'API 장애 주입 + X-Ray'(스택 d2-<ME>-api, 레이어 d2-<ME>-xray-sdk)도 함께 지웁니다.
# 순서: 실행 중 FIS 실험 중지 → FIS 템플릿 → SLO → 경보 → 대시보드 → 예약 조정
#       → d2-<ME>-api · X-Ray SDK 레이어 → d2-<ME> → d2-shared   (d2-shared 는 두 스택이 모두 지워진 뒤에)
set -uo pipefail
export AWS_REGION=ap-northeast-2 AWS_DEFAULT_REGION=ap-northeast-2
ME=${1:-${ME:-}}
[[ "$ME" =~ ^user[0-9]{2}$ ]] || { echo "사용법: bash ~/day2/setup/cleanup.sh user07 [--dry-run]"; exit 1; }
DRY=0; [[ "${2:-}" == "--dry-run" ]] && DRY=1

run() { if (( DRY )); then echo "  [dry-run] $*"; else echo "  $*"; "$@" >/dev/null 2>&1 || echo "    (실패 · 건너뜀)"; fi; }

echo "대상: 계정 $(aws sts get-caller-identity --query Account --output text) · 리전 $AWS_REGION · d2-$ME 과 d2-shared"
if (( ! DRY )); then
  read -r -p "삭제하면 되돌릴 수 없습니다. 계속하려면 yes 를 입력하세요: " ans
  [[ "$ans" == "yes" ]] || { echo "취소했습니다."; exit 0; }
fi

echo "① 실행 중 FIS 실험 중지"
for id in $(aws fis list-experiments --query "experiments[?state.status=='running' || state.status=='initiating' || state.status=='pending'].id" --output text 2>/dev/null); do
  run aws fis stop-experiment --id "$id"
done

echo "② FIS 실험 템플릿 (Owner=$ME 태그 또는 이름에 d2-$ME)"
for id in $(aws fis list-experiment-templates --query "experimentTemplates[?tags.Owner=='$ME' || contains(description||'','d2-$ME')].id" --output text 2>/dev/null); do
  run aws fis delete-experiment-template --id "$id"
done

echo "③ SLO (d2-$ME-*)"
for arn in $(aws application-signals list-service-level-objectives --query "SloSummaries[?starts_with(Name,'d2-$ME-')].Arn" --output text 2>/dev/null); do
  run aws application-signals delete-service-level-objective --id "$arn"
done

echo "④ 경보 (d2-$ME-*)"
for a in $(aws cloudwatch describe-alarms --alarm-name-prefix "d2-$ME-" --alarm-types CompositeAlarm MetricAlarm \
             --query "[CompositeAlarms[].AlarmName, MetricAlarms[].AlarmName][]" --output text 2>/dev/null); do
  run aws cloudwatch delete-alarms --alarm-names "$a"
done

echo "⑤ 대시보드 (d2-$ME-*)"
for d in $(aws cloudwatch list-dashboards --dashboard-name-prefix "d2-$ME-" --query "DashboardEntries[].DashboardName" --output text 2>/dev/null); do
  run aws cloudwatch delete-dashboards --dashboard-names "$d"
done

echo "⑥ 예약 조정"
for s in $(aws autoscaling describe-scheduled-actions --auto-scaling-group-name "d2-$ME-asg" \
             --query "ScheduledUpdateGroupActions[].ScheduledActionName" --output text 2>/dev/null); do
  run aws autoscaling delete-scheduled-action --auto-scaling-group-name "d2-$ME-asg" --scheduled-action-name "$s"
done

echo "⑥-1 API 실험 스택 d2-$ME-api · X-Ray SDK 레이어 (v2 추가, 약 2~3분)"
if aws cloudformation describe-stacks --stack-name "d2-$ME-api" >/dev/null 2>&1; then
  run aws cloudformation delete-stack --stack-name "d2-$ME-api"
fi
for v in $(aws lambda list-layer-versions --layer-name "d2-$ME-xray-sdk" --query "LayerVersions[].Version" --output text 2>/dev/null); do
  run aws lambda delete-layer-version --layer-name "d2-$ME-xray-sdk" --version-number "$v"
done

echo "⑦ 서비스 스택 d2-$ME (약 3~5분)"
if aws cloudformation describe-stacks --stack-name "d2-$ME" >/dev/null 2>&1; then
  run aws cloudformation delete-stack --stack-name "d2-$ME"
  (( DRY )) || aws cloudformation wait stack-delete-complete --stack-name "d2-$ME"
fi

if (( ! DRY )) && aws cloudformation describe-stacks --stack-name "d2-$ME-api" >/dev/null 2>&1; then
  aws cloudformation wait stack-delete-complete --stack-name "d2-$ME-api"   # d2-shared 의 내보내기 값을 쓰므로 먼저 끝나야 합니다
fi

echo "⑧ 네트워크 스택 d2-shared"
if aws cloudformation describe-stacks --stack-name d2-shared >/dev/null 2>&1; then
  run aws cloudformation delete-stack --stack-name d2-shared
  (( DRY )) || aws cloudformation wait stack-delete-complete --stack-name d2-shared
fi

(( DRY )) && { echo "목록 확인 끝. 실제로 지우려면 --dry-run 없이 실행합니다."; exit 0; }
echo
echo "남은 것 확인 (모두 비어 있으면 끝):"
aws cloudformation list-stacks --stack-status-filter CREATE_COMPLETE UPDATE_COMPLETE DELETE_FAILED \
  --query "StackSummaries[?starts_with(StackName,'d2-')].[StackName,StackStatus]" --output text
aws ec2 describe-instances --filters Name=tag:Lab,Values=day2 Name=instance-state-name,Values=pending,running \
  --query "Reservations[].Instances[].InstanceId" --output text
echo "✔ 정리 끝. CloudShell 홈 폴더(~/day2, ~/bin/k6)는 요금이 없으며 그대로 둬도 됩니다."
