#!/bin/bash
# 실습⑤ (추가) API 장애 주입 + X-Ray — 명령 모음. 필요한 줄만 복사해 실행합니다. (source ~/day2.env)

# A-0. 새 자료 풀기(덮어쓰지 않음) · 스택 배포
unzip -n ~/Day2_v2_실습자료_v2.zip -d ~/day2
bash ~/day2/setup/setup_api_v2.sh $ME

# A-1. 스택 출력값
aws cloudformation describe-stacks --stack-name d2-$ME-api \
  --query "Stacks[0].Outputs[].[OutputKey,OutputValue]" --output table

# A-2. 변수 — 출력값에서 자동으로 만드는 따라잡기 버전 (가이드에서는 손으로 입력)
o() { aws cloudformation describe-stacks --stack-name d2-$ME-api \
        --query "Stacks[0].Outputs[?OutputKey=='$1'].OutputValue" --output text; }
export API_URL=$(o ApiUrl) API_NAME=$(o ApiName) APP_FN=$(o AppFunctionName) APP_ROLE=$(o AppRoleArn) \
       FIS_API_ROLE=$(o FisApiRoleArn) FIS_API_LOG=$(o FisLogGroupArn) QUEUE=$(o QueueName)
env | grep -E '^(API_URL|API_NAME|APP_FN|APP_ROLE|FIS_API_ROLE|FIS_API_LOG|QUEUE)=' | sed 's/^/export /' >> ~/day2.env
cd ~/day2/lab3_api

# B. 정상 상태 · X-Ray
curl -s $API_URL/describe
bash run-api-throttle.sh 10
bash xray-traces.sh 10
bash trace-detail.sh

# C-1. 중지 조건 경보
aws cloudwatch put-metric-alarm \
  --alarm-name d2-$ME-api-stop-5xx \
  --namespace AWS/ApiGateway \
  --metric-name 5XXError \
  --dimensions Name=ApiName,Value=$API_NAME \
  --statistic Sum --period 60 \
  --evaluation-periods 1 --threshold 30 \
  --comparison-operator GreaterThanOrEqualToThreshold \
  --treat-missing-data notBreaching

# D-1 / E-1. 템플릿 (콘솔 대신)
bash ~/day2/정답/lab3_api/create-api-template.sh 3
bash ~/day2/정답/lab3_api/create-api-template.sh 4

# D-2. 내 템플릿 · ID
aws fis list-experiment-templates \
  --query "experimentTemplates[?tags.Owner=='$ME'].[id,description]" --output table
# export TPL3=EXT...   export TPL4=EXT...

# D-3 ~ D-5. 실험3 run1
export EXP3=$(aws fis start-experiment --experiment-template-id $TPL3 \
  --tags Owner=$ME,Name=api-throttle-run1 --query "experiment.id" --output text)
sleep 30; bash run-api-throttle.sh 30
bash xray-traces.sh 10; bash trace-detail.sh
aws logs tail /d2/$ME/fis-api-experiments --since 15m --format short | head -n 20

# D-6. 재시도 10회 · standard
aws lambda update-function-configuration --function-name $APP_FN \
  --environment "Variables={USER_ID=$ME,MAX_ATTEMPTS=10,RETRY_MODE=standard}" --query "Environment.Variables"
aws lambda wait function-updated --function-name $APP_FN

# D-7. 실험3 run2
export EXP3B=$(aws fis start-experiment --experiment-template-id $TPL3 \
  --tags Owner=$ME,Name=api-throttle-run2 --query "experiment.id" --output text)
sleep 30; bash run-api-throttle.sh 30; bash xray-traces.sh 5

# D-8. 되돌리기
aws lambda update-function-configuration --function-name $APP_FN \
  --environment "Variables={USER_ID=$ME,MAX_ATTEMPTS=5,RETRY_MODE=legacy}" --query "Environment.Variables"
aws lambda wait function-updated --function-name $APP_FN

# E. 실험4 — 실험 전 확인(NO) → 시작 → 동기(yes) → 비동기
bash run-api-unavailable.sh
export EXP4=$(aws fis start-experiment --experiment-template-id $TPL4 \
  --tags Owner=$ME,Name=api-unavailable-run1 --query "experiment.id" --output text)
sleep 30; bash run-api-unavailable.sh
bash run-api-unavailable2.sh
bash run-api-unavailable2.sh watch

# E-5. 근거
aws logs tail /aws/lambda/$APP_FN --since 10m --format short | grep -E '"async"|Task timed out|ServiceUnavailable' | tail -n 10
bash xray-traces.sh 10
aws sqs get-queue-attributes --attribute-names ApproximateNumberOfMessages \
  --queue-url $(aws sqs get-queue-url --queue-name d2-$ME-api-dlq --query QueueUrl --output text) \
  --query "Attributes.ApproximateNumberOfMessages" --output text

# 비상 중지
# aws fis stop-experiment --id <실험ID>
