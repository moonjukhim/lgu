#!/bin/bash
# 실습⑤ 콘솔 대신 CLI로 API 실험 템플릿 만들기 (따라잡기용)
#   bash create-api-template.sh 3   → 실험3 API 스로틀링
#   bash create-api-template.sh 4   → 실험4 API 사용 불가
# JSON의 __ME__ · __APP_ROLE__ · __FIS_API_ROLE__ · __FIS_API_LOG__ · __STOP_ALARM_ARN__ 자리를 내 값으로 바꿔 만듭니다.
set -euo pipefail
source ~/day2.env
cd "$(dirname "$0")"
case "${1:-3}" in
  3) SRC=exp3-api-throttle.json ;;
  4) SRC=exp4-api-unavailable.json ;;
  *) echo "3 또는 4를 입력하세요"; exit 1 ;;
esac
for v in ME APP_ROLE FIS_API_ROLE FIS_API_LOG; do
  [ -n "${!v:-}" ] || { echo "변수 $v 가 비어 있습니다. 가이드 A-2를 먼저 하세요"; exit 1; }
done
STOP_ALARM_ARN=$(aws cloudwatch describe-alarms --alarm-names d2-$ME-api-stop-5xx \
  --query "MetricAlarms[0].AlarmArn" --output text)
if [ -z "$STOP_ALARM_ARN" ] || [ "$STOP_ALARM_ARN" = "None" ]; then
  echo "중지 조건 경보 d2-$ME-api-stop-5xx 가 없습니다. 가이드 C-1을 먼저 하세요"; exit 1
fi
sed -e "s|__ME__|$ME|g" -e "s|__APP_ROLE__|$APP_ROLE|g" -e "s|__FIS_API_ROLE__|$FIS_API_ROLE|g" \
    -e "s|__FIS_API_LOG__|$FIS_API_LOG|g" -e "s|__STOP_ALARM_ARN__|$STOP_ALARM_ARN|g" \
  "$SRC" > /tmp/d2-api-exp.json
echo "== 만들 템플릿 (읽어 보고 확인하세요)"; cat /tmp/d2-api-exp.json
aws fis create-experiment-template --cli-input-json file:///tmp/d2-api-exp.json \
  --query "experimentTemplate.id" --output text
