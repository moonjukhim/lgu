# 따라잡기 파일 (정답)

오늘 실습은 **직접 입력**이 원칙입니다. 이 폴더는 2분 이상 막혔거나, 진도에서 한 단계 이상 뒤처졌을 때만 씁니다.

쓰는 법
1. 먼저 파일을 `cat` 이나 `nano` 로 **열어서 읽습니다**. 내가 입력한 것과 어디가 다른지 찾는 것이 목적입니다.
2. 다른 곳을 고쳐서 내 명령을 다시 실행합니다. 그래도 안 되면 이 파일의 해당 줄을 실행합니다.
3. `.sh` 파일은 통째로 실행하지 말고, 필요한 줄만 복사해 실행하는 것을 권합니다(특히 lab1_commands.sh).

| 파일 | 실습 |
|---|---|
| env.example.sh | 실습① A — 환경 변수 예시 (값은 내 스택 출력으로 바꿔야 함) |
| lab1_commands.sh | 실습① B~D · H 명령 |
| lab2/load.js, lab2/steady.js | 실습② · ③ 부하 스크립트 |
| lab2/observe.sh | 실습② 관찰 명령 3종 (한 번 실행) |
| lab2/prewarm.sh | 실습② 선택 과제 — 예약 조정 |
| lab3/exp1-terminate.json, lab3/exp2-cpu.json | 실습③ 실험 템플릿 (CLI 생성용) |
| lab3/create-template.sh | 실습③ 콘솔 대신 CLI로 템플릿 만들기: `bash create-template.sh 1` |
| lab3/run-observe.sh | 실습③ 안전 확인 → 실행 → 15초 간격 관찰: `bash run-observe.sh <템플릿ID>` |
| gate/gate.sh | 미니 실습 게이트 |
| lab4/lab4_commands.sh | 실습④ 명령 |

`diff ~/day2/lab2/load.js ~/day2/정답/lab2/load.js` 처럼 내 파일과 비교하면 틀린 줄을 빨리 찾습니다.

### v2 추가 — 실습⑤ API 장애 주입 + X-Ray

| 파일 | 실습 |
|---|---|
| lab3_api/exp3-api-throttle.json, lab3_api/exp4-api-unavailable.json | 실습⑤ 실험 템플릿 (CLI 생성용) |
| lab3_api/create-api-template.sh | 콘솔 대신 CLI로 템플릿 만들기: `bash create-api-template.sh 3` 또는 `4` |
| lab3_api/lab3_api_commands.sh | 실습⑤ 명령 모음 (A-2 변수 자동 생성 포함) |
